#!/usr/bin/env python3
import os,sys
a=sys.argv[1:]
os.execv('/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_R6_1/results/lookahead_accel_round6_1_20261109T160000Z/cpu61',["cpu61"]+a[:6]+["compact"]+a[6:])

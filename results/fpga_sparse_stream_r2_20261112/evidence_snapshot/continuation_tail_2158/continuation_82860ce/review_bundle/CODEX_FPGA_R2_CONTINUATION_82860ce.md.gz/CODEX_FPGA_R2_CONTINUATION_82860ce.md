# 给服务器 Codex：R2 接续、证据收齐与 wave 私有归约候选

审阅基准：`82860ced203bde54f1fa267446b3d0edc521a293`  
现有分支：`accel/lookahead-sparse-stream-r2-20261112`  
文档性质：在现有 R2 上继续工作的执行指导；不是新测量结果，也不替换历史任务文档。  
时间范围：本指导依据固定提交内截至 `2026-11-13T17:28:18Z` 的运行快照；执行时必须刷新服务器状态。

## 0. 直接执行的任务与约束

继续完成现有 R2。先接管已有三个 OOC 作业、归档已完成结果、恢复中断的 P8/F0 校准，再按既定计划补齐 F0 完整 batch。与此同时，用轻量画像和有限容量软件原型验证一个新性能方向：**每个 wave 私有、初值 INF 的 destination-line accumulator，wave 结束后才读旧 label 并一次提交**。

最终目标保持“FPGA 优于各个基线；GPU 与 CPU 不要求排序”。本轮结论可能是有条件可行或某候选失败，不得预设排序。可以继续无板 RTL、OOC 和架构仿真研究；没有实板本身不是停止这些实验的理由。

已授权范围内自主完成实现、验证、归档和独立分支推送。不要反复请求是否继续。保护 main、原稿、STRICT、旧 golden、所有历史负结果和未跟踪指导文档。不得 reset/clean 覆盖现有工作。不得改写仍在运行作业使用的 frozen RTL/model/OOC context。

这次不是从 R1 重做 R2：POP 在线 whole-pair reduction、真正的 owner pipeline、changed/commit pipeline、外部有限 node-state backing、共享物理通道和 Q=1 完整 batch 控制已经存在，应直接复用。

## 1. 先确认当前事实

### 1.1 拓扑与进度

- `P32`：32 owners、32 个物理服务通道。
- `P8`：**仍是 32 owners**，改为 8 个共享物理服务通道；不是 8-lane/8-owner 核。
- 某些 `many8_*` 的 125 MHz 资格仅适用于其自身 8-owner 完整核；不能移给 P8 或 P32。
- 每个物理通道 64 credits。P32→P8 同时将总 credits 从 2048 降到 512，比较解释必须保留这一点。
- F0 关闭 proposal owner 合并缓存，**保留 node-state cache**；不能称为完全无缓存。

固定提交的进度：

| 项目 | 已知状态 | 接续动作 |
|---|---|---|
| P32/F1 完整 OOC | 快照时进行中 | 刷新原作业状态，接收其终态 |
| P8/F1 完整 OOC | 快照时进行中 | 同上，不重启 |
| P8/F0 完整 OOC | 快照时进行中 | 同上，不重启 |
| P8/F1 八项完整 batch 模型 | 全部完成并通过审计 | 归档尚缺的六套原始 trace；不重跑 |
| P8/F0 RTL/校准 | 旧 supervisor/进程中断，已有多个阶段通过 | append-only 恢复未完成尾项 |
| P8/F0 六项 native 模型 | 未启动 | 新并发域校准通过后按既定计划运行 |
| 两项新结束的 OOC 负结果 | 尚需补全归档 | 收齐终态报告、失败原因与源绑定 |

### 1.2 软件目标已经更新

新 prepared CSR＋valid POP 的 `RESIDENT_COMPLETE_BATCH_V2` 实测均值如下。均为完整原生 40-sample batch，不是单 sample，不是旧 E2，也不是整个 VPR process。

| 输入 | basic prepared CUDA | compact prepared CUDA | 每例最佳已测 CUDA |
|---|---:|---:|---:|
| BNN | 0.156690577111 s | 0.151799969444 s | 0.151799969444 s |
| LSTM | 0.159888578444 s | 0.160247990444 s | 0.159888578444 s |

保留两种 CUDA 的全部过程与离散度；LSTM 的小差别不应夸大为显著性能区别。旧约 0.305 s 的 CUDA 仅作历史结果，不能作为当前最强对照。

同一 H100 worker 的 transformed 8-thread CPU 均值为 BNN 4.534045816222 s、LSTM 4.623006792333 s。另一台有 Vivado 并发负载的主机测得 3.307430729/3.438127634 s；两套测量不能拼接成同机速度比。原 VPR 多线程、optimized STRICT 与 native E2/Process 沿用各自 cohort 和范围，不与 resident V2 混用。

## 2. 轨道 A：恢复并完成现有 R2

### A0. 刷新状态，统一当前状态入口

1. 读取适用的 AGENTS.md；核对当前 worktree、分支、HEAD、main、tracked/untracked 文件和受保护文件哈希。
2. 确认当前 worktree 属于目标 R2 分支，并检查 82860ce 是否为 HEAD 的祖先。如果远端或本地已有后续提交，检查日志、差异及运行回执并保留它们；不得回退到 82860ce。若两端分叉，不得用 reset、force-push 或覆盖工作区追齐。以最新已核对状态接续，将本指导基准保留为审阅出处。
3. 对三个原 OOC 查询实际 session/run 状态与日志。进程身份结合 PID、启动时间、当前 Tcl 的绝对路径、父子进程、实际工程/run 日志和冻结绑定，不能只凭一个可能复用的 PID。MCP 会话可能复用历史 cwd；cwd 只能作辅助，不能因它仍指向旧目录就判定作业失联或启动重复作业。
4. 若仍运行，继续现有 run；若已结束，读取现有终态；只有确认中断且现有工具提供可靠 resume 时才恢复。不得 source 第二份正在 wait 同一 impl 的父脚本，不得重复 launch。
5. 当前 checkpoint 中 `active_physical_jobs`、`active_vivado_sessions`、旧 `pending_commands`、`next_action`、README 摘要和 `branch_pushed` 有历史状态混杂。建立一个带 `observed_at` 的逐作业当前 manifest，再从它生成摘要。保留历史快照，不伪装成实时状态。

### A1. 先归档已存在的证据

- 六项 P8/F1 新完成的完整 batch trace：保存 summary、逐 wave 工作集合/计数、流量、阶段周期、输入/输出 SHA、可执行文件与编译宏、校准引用及终态 receipt。
- 两项新失败 OOC：保存 synth/place/route 日志、实际 terminal status、资源、route_status、DRC、setup/hold/pulse/check_timing、源/参数/约束绑定和失败定位。
- 非法路由、拥塞失败或 hold 未通过时，不发布合格频率；也不要以降频消除非法路由为目标重做无依据扫描。
- 已完成 trace 只做增量归档与清单验证，不再跑同一模拟。文件缺失则明确缺失，不凭汇总重建成“原始 trace”。

### A2. 安全恢复 P8/F0 校准

当前脚本存在明确恢复限制：`validate_many_candidate.py` 拒绝已有 pipeline receipt；热点测试目录及某些 boundary 校准目录不允许覆盖。因此**不要直接重跑旧总命令，也不要删目录后重来**。

实施一个小型、可审计的 resume 入口，或给现有入口添加显式 resume-manifest 支持：

1. 保留中断时旧 receipt 和部分产物；记录它们的哈希与最后成功阶段，不擅自推断中断原因。
2. 对冻结 RTL、模型源码、可执行文件、宏、参数与 OOC context 重新核对身份。
3. 身份完全相同才复用原已通过阶段。已有 d3/d4、91 fixtures、压力/大地址、独立校准、36 fixed-ns 及 Q40 等结果逐项读取 receipt；不要凭文档计数宣称通过。
4. 未完成的 hot8192、尚未完成/启动的 overflow8193、对应四项 boundary calibration 以及 18 项 10ns 补充，用新的 run tag 和新目录只运行缺失项。已经完成其中某项则直接核验复用。
5. 新 recovery manifest 引用旧通过结果和新尾项，不更改旧 receipt 的 running/failed 历史状态。gate loader 应验证完整阶段覆盖与同一候选身份。
6. 只有目标 P8/F0 的全部必要门通过，才生成本版本 native-plan 资格。P32/F0 校准不能替代 P8/F0。

若发现真正 RTL/model bug，保存失败案例后生成新 candidate identity；受影响的旧校准不能继续冒用。不要通过放宽 gate 掩盖缺少阶段。

### A3. 完成六项 P8/F0 同条件消融

复用 `config/p8_f0_native_plan.json` 的既定计划：BNN、LSTM 各自 `60/gap2`、`16/gap2`、`16/gap1`，共六项；不新增笛卡尔积扫描。

- 先运行 gated runner 的 check-only，再启动剩余实际任务。
- 每次均为一次 start、40 samples、Q=1；完整 mutable initialization、cost/job、结果写出与 ACK 计入。
- 在输出、逐 wave 集合、容量、流量和 ACK 检查通过后，比较同输入、同端口、同内存合同的 F0/F1。
- 没有全核频率资格不阻止报告模型 cycles、流量和缓存消融；FPGA seconds 保持 null。
- 控制并发，避免新 CPU 密集分析妨碍现有 OOC；对照软件计时不能在新重负载下随意补测。

### A4. 接收三项 OOC 的最终结论

对每个实际候选独立记录：器件、top、宏、容量、布线是否合法、资源、setup/hold/pulse、时钟约束及全部待修复路径。不继承其他 topology 的频率。

完整 OOC 通过可支持“核内部 post-route 时序资格”；不等于 board measurement，也不等于接入实际 HBM shell 后的系统时序资格。建模的外部随机服务仍是明确合同。

结束轨道 A 的条件：现有 OOC 均有终态或明确的可继续运行状态；已完成结果归档；P8/F0 校准和六项计划有逐项结果；当前状态摘要与真实作业一致。若长 OOC 仍未完，报告其真实状态并继续监督，不写“全轮完成”。

## 3. 固定架构的两个性能门槛

### 3.1 工作量门槛独立于访存

BNN、LSTM 的候选数分别为 1,286,937,147 和 1,309,512,712。固定 32 lanes、每 lane 每周期最多一个候选时：

`C_edge_lb = ceil(candidate_count / 32)`

分别至少 40,216,786 / 40,922,273 cycles。若仅用于规划而假设 200 MHz，新 GPU 时间允许约 30,359,994 / 31,977,716 cycles。因此**32×II1、≤200MHz、候选工作不变的实现，即使没有内存和控制开销也不能超过当前 GPU**。

| 假设频率 | BNN 仅边工作所需最少理想 lanes | LSTM 同项 |
|---|---:|---:|
| 100 MHz | 85 | 82 |
| 125 MHz | 68 | 66 |
| 150 MHz | 57 | 55 |
| 200 MHz | 43 | 41 |

这些是必要下界，不是可实现结构。64 lanes 在 125 MHz 仍不够。32 lanes 所需仅边工作频率已是约 264.93/255.94 MHz，尚未计初始化、归约、提交和停顿。

当前 P32 最快已完成 F1 模型在 16/gap1 下是 145,758,496 / 149,850,247 cycles；P8 相同合同为 359,062,210 / 366,543,747 cycles。全核时钟未知，不能发布 FPGA 实测秒数。

### 3.2 流量门槛

以 P32/F1 60/gap2 为明确诊断点：

| 内部流量（十进制 GB） | BNN | LSTM |
|---|---:|---:|
| proposal read | 34.533 | 35.231 |
| proposal write | 4.997 | 5.103 |
| state read＋write | 21.906 | 22.309 |
| CSR＋metadata＋cost/job/output | 14.043 | 14.386 |
| 总计 | 75.479 | 77.029 |

proposal/state 合计约 81.4%。BNN 的 owner hit/merge/miss 分别约 14.80%/9.44%/75.76%，state hit 约 28.97%。两类 32-entry MSHR 和 16-entry dirty queue 均达到峰值。

`proposal_read_transactions = owner_misses + changed_commits` 在这两个已审计结果上成立。仅 expansion miss 已触发约 31.198/31.834 GB proposal 读取。这是首要目标。

同一模型中 active POP＋重叠边处理约占 81.7%，changed commit 约 10.4%，初始化约 6.6%，原桶 closure＋POP reduce drain 仅约 0.0043%。不要再把优化“闭合全图扫描”作为本轮尚未实现的主要任务。

在假设 200MHz、每事务32B下，仅由通道发起服务得到的最大可支付流量为：

`D_budget = GPU_seconds × physical_ports × 32 × frequency_Hz / gap_cycles`

| 假设合同 | BNN 预算 | LSTM 预算 |
|---|---:|---:|
| P32 gap1 | 31.089 GB | 32.745 GB |
| P32 gap2 | 15.544 GB | 16.373 GB |
| P8 gap1 | 7.772 GB | 8.186 GB |

相比当前流量，P32/gap1 也至少要减少约 59%/57%；gap2 约79%。上述预算忽略最忙端口、响应延迟、竞争、阶段屏障和其他工作，只有必要性意义。

最终应使用 `max_port((requests_port-1)×gap+1)` 和有限队列模型，而不是仅靠总字节。不同 wave 的 expansion 和随后 apply/commit 不可以全部视为重叠；不同 owners 的 stall counter 不能相加当作全局时间。

## 4. 轨道 B：优先实现 wave 私有 INF 归约的有限原型

### B0. 语义目标

对现有 ALT 合法数值域，令 `Lw` 为 wave 起点标签，`Aw` 为该 wave 的有效 active 集合：

`Mw[v] = pair_min({FP32AddPair(Lw[u], cost(v)) | u in Aw and eligible(u,v)})`

`Lnext[v] = pair_min(Lw[v], Mw[v])`

空候选集合的 `Mw` 为 INF pair。这样可以先在私有累加器中归约候选，而不在每次 owner miss 时读取旧 proposal。所有候选退休并完成必要归并后，才读取旧 label、判断是否改善、执行一次逻辑提交。

成立条件：

- FP32 加法的每条边输入及运算顺序不变，仍用冻结的 wave-start parent label。
- 归约的是整个 delay/congestion pair 的词典序最小值，不能分别取两个分量最小值。
- 沿用现有 numeric admission；不静默接受 NaN、负零、非法负值或溢出，INF 只作为原合同允许的内部 sentinel。
- active 集合、有效 POP、桶选择和 early termination 规则不变；线上 POP 输出归约仍保持原语义。
- 每个 improved node 一次逻辑 commit，pending/version、目录发布及其 ACK 全部完成后才进入下一 wave。
- 全部中间状态显式属于 sample/wave；epoch wrap、异常重启与溢出有确定行为。
- 只主张 ALT 输出等价，不能改成 STRICT 等价。保留既有 congestion 反例和 native 资格边界。

不要将旧 proposal 与 canonical label 直接别名：现有 POP 与 expansion 重叠，别名会让晚 POP 读到本 wave 新值。

### B1. 必须先补的画像

现有 changed 峰值不是 accumulator 容量。要补全部 touched destination lines：

- 每 wave `unique_touched_line4`、`unique_touched_line2`、`unique_changed_line4/2`。
- 同项每 owner、每拟议 subbank 的峰值与分布。
- candidate→同 line 重复次数和有限窗口可合并率。
- 按 opcode 的 state accepts/misses/dirty writes，用于分离 MARK/CLEAR 与 POP/COMMIT。
- 候选接受/退休、同 line RAW 冲突、bank 冲突、spill 反压、每物理端口请求量。

从现存逐 wave touched-node 计数能严格推出以下容量界，但尚未测得真实 distinct-line 峰值。设该 wave touched节点数为T、changed4-node行数为C，则 `max(ceil(T/4), C) <= U4 <= T`。下表156,917/158,139是峰值下界，不能作为实测峰值直接配置容量：

| 全 resident 所需 line entry 峰值区间 | BNN | LSTM |
|---|---:|---:|
| 全局 4-node line entries | 156,917–627,667 | 158,139–632,554 |
| 仅32B pair payload | 5.021–20.085 MB | 5.060–20.242 MB |

32 owners×4096 entries＝131,072，连全局下界都不足。32×8192＝262,144 是否够尚不确定，必须测真实 owner/subbank 分布、碰撞和负载率。tag/mask/FIFO/冲突处理及 RAM 组织浪费另计。

画像可逐流记录统计摘要与被选择的最坏 wave，不要求保存全部约13亿候选的巨大文本 trace。全输入功能结果仍需保存哈希与可重现入口。

### B2. 有限 C++ 原型与可行性 screen

先实现一个功能 oracle，再实现容量有界的性能原型。功能 oracle 可以用通用容器验证数学结果；**性能模型不能把通用无界 map 作为硬件资源**。

每 entry 保存明确 line tag、4个pair、sector-valid mask、epoch/状态。容量同时列出 `owners × subbanks/owner × entries/subbank`；不能把原来每owner 8192 entries在双subbank后悄悄变成每subbank 8192 entries。选择一至两个有画像依据的固定组织；记录每个 RAM 的 width/depth/ports、同步读延迟、写回规则、容量拒绝或 spill。不得做大范围 cache size/associativity 扫描。

优先评估直接访问当前 128-bit canonical state 的布局：每32B装两个节点。最终 apply 按实际 sector mask 读取该4-node line对应的一个或两个32B state整行（没有免费的16B半事务），合并同一 state line 的更新，将 label/pending 检查和写回合为有限 RMW 服务。两个state行的地址应沿用实际owner-interleaved映射，不能假定为全局相邻的64B burst。避免长期保留两个镜像并仍支付全部旧 state 成本。

另一布局是 packed64 label 镜像（4节点/32B），但如果保留原 node-state，则其初始化、同步读写、POP/pending 流量必须全部计入；不能重复享受“只读一次 label”的账面收益。

已有计数给出的已知部分区间如下，**尚不含所有额外成本**：

| 保留现有 CSR/metadata/output，另计各布局列明的初始化 | BNN | LSTM |
|---|---:|---:|
| packed64读/写＋镜像自身初始化，保留state128的成本另加 | 19.726–27.764 GB | 20.174–28.367 GB |
| 按 sector mask 访问 state128 的已知部分 | 23.754–30.653 GB | 24.275–31.304 GB |

额外成本包括尚未计入的 POP/pending、目录、spill、归并 pass、队列/epoch 元数据，以及保留镜像的全部同步成本。state128最终合并RMW已计入的label/pending读写不得再重复收费。packed64行仅计镜像初始化；若仍保留state128，其初始化还需约2.626/2.667GB及其他必要服务。区间来自 touched-line 上下界，不是精确流量预测。

明确wave末如何枚举和清空resident entries：全表扫描或有限occupied-slot列表。扫描、列表写入/遍历、去重、epoch检查、异常清理及sample初始化均计入。epoch不能消除枚举。若每个subbank每wave扫描8192 slots，即使所有subbanks并行、每周期检查一个slot，BNN/LSTM仍分别需17,702,912/18,022,400扫描周期；不能把这部分免费化。有限occupied-slot列表需要容量、背压和重复slot处理。

由此可见：P32/gap1 在200MHz规划下尚有条件机会；P32/gap2 连这些已知乐观下界都不能通过。若仍固定P32、≤200MHz、gap2及当前读回合同，就必须进一步减少CSR/metadata/初始化或其他流量；改变端口数、实际合格频率或服务合同时需重新计算预算。不得只挑 gap1 隐藏其他合同的失败。画像可能发现当前 CSR row 和 cell metadata 的行利用率很低，可以将 source-line 合并/重排作为有证据的后续方向，但新增重排、索引、缓冲和预处理都要计入。

### B3. 有限 overflow，不能靠无限缓存通过

推荐研究“只 spill 已局部归约的片段”，而非把所有原始候选写外存：

1. resident entry 从 INF 开始合并。
2. 容量/冲突驱逐时写出不可变 `line_id + mask + partial_min_pairs`，只有获得有限写缓冲和 credit 才允许驱逐。
3. 同 line 再出现可从 INF 形成新片段。
4. wave 末对 resident 与全部 spill 片段做精确最终归并；每个 improved node 只逻辑提交一次。
5. spill 区、归并 scratch、pass 数和 FIFO 都有限；容量不足明确拒绝或受控 fallback，不静默丢结果。

按实际事务粒度计费：40B片段若独立占两个32B行，一次写＋读可达128B；只有实现跨片段连续打包才能使用约80B下界。反序 ACK、晚返回和 backpressure 必须真实阻塞。

全部原始候选以12B/16B记录写一次再读一次，仅日志即约30.9/41.2GB（BNN），还没读 CSR 和 state，不能将“外部排序所有边”当作免费解决方案。

### B4. 同时跨过计算吞吐门槛

仅减少访存不能解除32×II1的工作下界。首选评估“32个owner组，每组两个独立subbank/候选处理端口”，并将前端候选生成、网络、FP32单元和退休端一起覆盖，或提出有语义证明的候选工作减少方法。

这是一项候选结构，不能只把模型 lanes 参数改成64。当前32bit发射掩码、网络端口宽度、仲裁、FIFO及client ID限制要实际修正；如果保留32 owners而增加候选 lanes，也应分别参数化这些维度。

每个普通 RMW 通常要一次读＋一次写。双口 URAM 每端口每周期只能读或写，不自动支持两个独立 RMW/周期。两个 subbank 各自1R/1W、同 line 合并/forwarding、冲突排队及实际倾斜分布必须进入模型和 RTL。hash 多路查询会造成 RAM 组织浪费和额外端口；不要只算原始bit数。subbank 必须使用 owner 索引之外的地址位，例如 `owner=line4[4:0]` 时可评估 `subbank=line4[5]` 或经过验证的独立 hash，不能再次使用已固定的 owner 位。同 line 必须稳定归同 subbank。两个 subbank 仍共享所属 owner 的物理端口/credits，不能因复制片上端口就在模型中新增外存带宽。

若完整核最终只闭合125MHz，64个理想候选端口仍不够超过新GPU，应如实判定该组合不足。规划200MHz不等于已获得200MHz资格。

## 5. 物理结构：与流量优化一起减少通用交换范围

现有 P32/F1 布局约107万 LUT，SLR CLB占用接近97.5%/100%/98.8%；P8/F1约91.2万 LUT，仍有SLR接近100%。这些是布局报告，不是已通过路由后的资源与频率资格。

P8 确实缩小了 fabric，但16/gap1的完整周期比P32慢约2.46/2.45倍；降低端口数是资源—吞吐权衡，不能只凭LUT降低认定更优。

已核对当前 backing region 和 metadata stride 按256个32B行对齐。proposal/state/POP metadata 的地址满足 `port = owner mod P`。因此新候选可将这些请求改为 owner-affine 直连或固定小组仲裁：P32每owner固定端口，P8每四owner共享一个端口。CSR edges、全局 controller仍需要共享通路。

为任意新输入增加 base/stride 对齐检查，保留现有8192B对齐是直接选择。局部网络需有 registered ready、有限 elastic buffer和明确credit，不增加跨SLR的组合ready环。此项缩小网络，**不直接减少内存字节**，也不自动解决候选路由网络的所有路径。

不要同时上大规模新cache、64全互连和多个物理扫参。先在低资源原型证明服务，按实际 critical path 做一次有因果依据的修改，再冻结完整候选。

## 6. 可选小消融：只有在能帮助决策时执行

### 6.1 changed membership 片上位图

若需要低风险验证 state 控制成本，可在现结构中单独把 MARK/CLEAR 搬到片上有限位图；MAX_N=4,194,304 时原始payload为512KiB。保留 first-mark 与FIFO容量申请原子性、同字RAW forwarding和wave尾清理。

按现有操作守恒，BNN/LSTM可移走229,339,702/234,134,235条 state-cache 逻辑命令，约52.54%/52.61%。这是推导的命令数，不等于省掉同百分比外存流量。必须测 opcode miss/writeback 才能量化。

新 wave accumulator 若已消除同类 MARK/CLEAR，就不必再开发一个重复功能的全规模位图分支。

### 6.2 changed-line commit 合并

把同 line 的多个 changed nodes 合并读取可省至多1.672/1.699GB，约占总proposal-read的4.8%。它可做清晰的小消融，但不是约35GB proposal-read主头的解决方案，不应独占下一轮资源。

## 7. 新候选的推进门与真实交付

### C1. 画像＋有界模型

输出精确 touched-line 分布、选定容量、spill 上限、每端口完整流量、分阶段服务与RAM组织。通过全部原生40-sample输出、既有小图和数值/语义反例验证。模型周期不继承旧 RTL 校准。

把理论下界和有界服务估计分开。只有同时有希望跨过计算、流量、容量三个必要条件，才启动新 RTL。某个内存合同失败就保留该失败；若仅快服务合同有希望，标为条件候选，不能宣布普遍加速。

### C2. 一个有限 RTL 微原型

实现单owner或少量owner，两个真实subbank，有限FIFO、spill credits与有限backing testbench。使用确定的实图代表wave和构造边界验证：

- first touch 不读旧 label；同 line 和多sector整pair min正确。
- 两路同拍输入分别覆盖不同subbank、同subbank不同行、同line同sector和同line不同sector；核对接受/退休守恒、RAM端口占用与RAW forwarding。
- 旧label优于全部候选时不commit。
- 恰好容量/容量+1；同line反复驱逐、跨片段归并。
- 反序ACK、spill背压、晚到响应和所有FIFO排空。
- 最终每improved节点一次逻辑commit。
- sample/wave切换、epoch wrap及超容量拒绝无错误输出。

分别记录 accepted/retired II、反馈延迟和完整wave周期；不能把一次最小入队间隔当作持续吞吐。小核能闭合时序不赋予完整核频率。

### C3. 完整集成与证据

若 C2 与完整预算通过，集成真实大容量、实际owner/端口拓扑及全部控制，使用本版本完整小图RTL/模型校准，随后完成BNN/LSTM各40sample的完整架构仿真与全核OOC。

每个完整结果必须绑定本版本RTL/model/macros/约束/内存合同。未经完整核合法路由和setup/hold/pulse资格，不将cycles换成主结果中的FPGA seconds。带假设频率的screen可单独列出。

对 wave 私有归约和推迟旧 label 比较，先核对当前 CPU/CUDA 是否已有等价机制；已有则记录并复用。若新方案提供软件也能采用的读取、初始化或归约工作消除，或者减少eligible工作、改变提前停止、改变prepared表示，须给CPU/CUDA相应对照并更新同范围性能预算。该核对在C1期间开展，不等完整硬件完成后才发现基线变化。纯硬件bank、端口和spill组织无需机械复制为软件实现，但软件应保持当前最佳合格版本。

## 8. 报告与论文口径

三个范围分别报告：

1. **Resident V2**：数据已装载的完整原生batch，从batch start到所有结果及必要ACK完成。初始化、内部存储访问、归并、overflow、输出和控制均计入。
2. **E2**：真实lookahead构建，含该范围内格式转换、准备、传输、主机发起与读回；若没有实测硬件则是明确分项的模型，不与软件实测冒充同类测量。
3. **Process**：整个VPR进程。不能用resident核心收益代替。

无板研究可以发表RTL校准＋完整架构仿真＋核内OOC支持的条件性能结论；应写“在指定有限存储服务模型和通过时序的核频率下的预测”，不能写“实板实测”。不能用AI猜测的IO数字当测量值。

推荐当前状态字段：

```json
{
  "board_measured": false,
  "whole_kernel_timing_closed": false,
  "whole_kernel_clock_mhz": null,
  "memory_service_evidence": "explicit_bounded_simulation_contract",
  "resident_complete_batch_model_verified": "per_candidate_and_contract",
  "fpga_simulated_superiority_supported": false
}
```

仅在相应证据实际产生时更新。OOC全核资格通过后，应另外保留shell/board未验证边界。

论文贡献围绕问题与机制：原owner miss造成读放大；ALT wave契约允许先片上归约再读取旧标签；有限容量和spill保证完整输入；局部化网络与真实多bank服务形成可实现结构；最后用匹配软件与完整batch验证。负结果作为设计决策依据，不以“审计通过数量”替代性能或创新性。

## 9. 最少交付文件

在适当的独立目录创建，不覆盖历史指导：

- `docs/lookahead_fpga_sparse_stream_r2_continuation.md`：R2实际收齐结果、尚在运行项、F0/F1对照与最新状态。
- 新 recovery manifest 和对应终态 receipts。
- 缺失原始trace与失败OOC归档及checksum索引。
- `analysis/wave_accumulator_profile.json`：精确line4/line2、owner/subbank分布、计数定义。
- `analysis/wave_accumulator_budget.json`：有界存储、每端口字节、分阶段cycles、spill/merge/初始化完整账目与必要性结论。
- 若通过C1：真实RTL/testbench、独立模型、校准与局部时序报告；若进一步通过，完整batch和完整核OOC结果。
- 一份可复现入口或脚本清单，不依赖未记录的交互命令。

推送后核对本地/远端SHA。总结区分已完成、仍运行、因具体证据失败的候选及下一项可执行动作。未结束的作业不能写成全轮完成；停止某候选不等于停止所有已授权任务。

## 10. 依据

项目固定提交：

- [R2主报告](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/blob/82860ced203bde54f1fa267446b3d0edc521a293/docs/lookahead_fpga_sparse_stream_r2.md)
- [完整native默认场景诊断](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/blob/82860ced203bde54f1fa267446b3d0edc521a293/results/fpga_sparse_stream_r2_20261112/analysis/completed_native_0252.json)
- [P32/P8同gap1比较](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/blob/82860ced203bde54f1fa267446b3d0edc521a293/results/fpga_sparse_stream_r2_20261112/analysis/ports8_vs32_gap1_cacheguard_1404.json)
- [有限backing布局](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/blob/82860ced203bde54f1fa267446b3d0edc521a293/results/fpga_sparse_stream_r2_20261112/analysis/native_backing_layout_1044.json)
- [RTL目录](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/tree/82860ced203bde54f1fa267446b3d0edc521a293/accel/lookahead/fpga_sparse_stream_r2/rtl)
- [ALT wave契约](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/blob/82860ced203bde54f1fa267446b3d0edc521a293/accel/lookahead/round6_1/bucket61.hpp)
- [语义参考](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/blob/82860ced203bde54f1fa267446b3d0edc521a293/accel/lookahead/fpga_sparse_stream/reference.cpp)

方法参考：

- [Graphicionado，MICRO 2016，作者全文](https://taejunham.github.io/data/graphicionado_micro16.pdf)：临时目的顶点属性在片上归约、source/destination分区的启示。该设计使用eDRAM，是ASIC研究；不能将其存储面积、频率或加速比直接移植为FPGA结果。
- [ReGraph，2022，作者论文](https://arxiv.org/abs/2203.02676)：针对局部性差异采用资源不同的流水，避免把大量相同复杂服务复制到所有通道。其报告数字不能替代本任务验证。
- [AMD UG573：UltraRAM端口操作](https://docs.amd.com/r/en-US/ug573-ultrascale-memory-resources/Dual-Port-SRAM-Array-Operations)及[UltraRAM组织](https://docs.amd.com/r/en-US/ug573-ultrascale-memory-resources/UltraRAM-Summary)：同步双口，每端口每周期执行读或写；4K×72组织。必须按实际端口、宽度和深度实现有限服务。

本指导中的wave私有累加器及其后续结构是依据当前代码和统计提出的候选；尚未实现、未取得新RTL/OOC资格、未证明超过软件。

# 给服务器 Codex：先修复交付脚本，再验证一个有针对性的 INF 存储候选

审阅提交：`5af99087a9d7055d468cc5269326d985b911919d`  
目标分支：`accel/lookahead-sparse-stream-r2-20261112`  
定位：上一份 `CODEX_FPGA_R2_CONTINUATION_82860ce.md` 的增量接续；不重做已通过的恢复和画像。  
快照时间：2026-11-13 21:54:37 UTC，即北京时间2026-11-14 05:54:37。下文运行状态不代表执行此指导时的实时状态。

## 0. 执行摘要

按以下顺序继续已经授权的研究与交付：

1. 立即核查并修复新 INF GPU worker 的源文件与头文件打包缺陷。
2. 修复 native finalizer 会把自身 manifest 更新当作外部脏改动的逻辑。
3. 继续接收六项原 P8/F0 模型和原 P8/F0 OOC，不重启；新软件结果到达后独立分析、归档和更新预算。
4. 新硬件只推进一个明确候选：BRAM metadata＋flat URAM payload，packed64 canonical label＋17-bit on-chip pending，32B spill payload＋有限状态管理。先证明状态变换和有限服务，再决定完整集成。

未获得完整核资格前，主结果继续 `fpga_seconds=null`、`board_measured=false`。没有实板不阻止RTL、OOC和明确合同下的架构模拟。通过局部时序不代表完整核通过；必要下界通过不代表速度胜出。

保持main、原稿、STRICT、旧golden、失败记录和未跟踪指导文档不变。先确认当前HEAD、分支、祖先关系、活跃任务身份；若已有后续修复，复用并记录，不能回退到审阅提交。不要重复提交同一GPU任务，不要覆盖旧run目录，不要force-push。

## 1. P0：两个需要先修复的确定性问题

### 1.1 GPU worker遗漏INF源文件与全部项目头文件

审阅文件：`accel/lookahead/fpga_sparse_stream_r2/sim/gpu_private_inf_worker.py`。

该版本创建全新的 `source` 目录后只复制：

```python
cuda_prepared_pop.cu
cpu_prepared_pop.cpp
```

随后首先编译：

```python
source/cuda_private_inf.cu
source/cpu_private_inf.cpp
```

这两文件没有被复制。四个源码还都 `#include "bucket61.hpp"`，但当前编译只有 `-I source`，也没有复制其依赖闭包。因此只补两个INF源文件仍不够。

需要冻结并校验的编译输入至少为：

```text
fpga_sparse_stream_r2/cuda_private_inf.cu
fpga_sparse_stream_r2/cpu_private_inf.cpp
fpga_sparse_stream_r2/cuda_prepared_pop.cu
fpga_sparse_stream_r2/cpu_prepared_pop.cpp
round6_1/bucket61.hpp
round6_1/compact61.hpp
round6_1/directory61.hpp
include/io.hpp
include/backend.hpp
include/workload.hpp
```

这些路径相对 `accel/lookahead/`。使用实际include关系构建可复现的source快照，保持include解析正确；若平铺，核对同名冲突和全部引号include。保存每个文件的原路径、SHA256、编译命令及生成二进制SHA。修复不改变编译浮点约束、线程数或计时边界。

执行顺序：

1. 查询 `job-7977d112-86f2-42f0-9c4e-6481294f1e30` 的真实状态、执行worker SHA、输出目录和build日志。
2. 若仍排队且确认会用坏版本，保存队列状态后取消这个已确认有缺陷的排队任务，以冻结修正版和新tag重提；不要碰模型或Vivado任务。若服务器已修好或任务在正常运行，按实际证据接续，不按旧提交盲目取消。
3. 若已因构建失败结束，保留失败及旧目录 `private_inf_gpu_a`，新版本使用新tag。
4. 在耗用GPU前完成文件完整性检查和CPU编译检查；CUDA编译可在有匹配toolkit的环境先完成，或分配节点后的第一阶段立即完成。编译失败应生成明确终态。
5. 成功构建后运行既定fixtures和native计划，不另加重复大规模测量。
6. watcher的job ID、run tag、结果目录应参数化；旧watcher目前硬编码旧任务和旧目录。新watcher使用新receipt目录，不能通过覆盖旧receipt伪装接续。同时检查observe_continuation.py、finalize_recovered_native.py及分析入口的旧job/tag/目录硬编码，以新的launch receipt或运行配置指针定位当前任务，保留旧历史。更新后核对current_manifest的任务身份和观察时间。

### 1.2 Native finalizer会被自身更新的manifest阻止

审阅文件：`sim/finalize_recovered_native.py`、`sim/observe_continuation.py`。

当前顺序为：

```text
observe_continuation.py
  → 重写已跟踪 current_manifest.json
freeze / verify
  → git diff --quiet
  → 因自身manifest改动而拒绝发布
```

保护用户改动的原则应保留，修复顺序与归属判断：

- 在本次监督器自身写入前记录/检查tracked和index状态；拒绝或明确保留无关改动。
- 运行后只允许本任务明确生成的文件白名单变化；校验它们的生成receipt/哈希。
- 使用精确pathspec stage；不能删除保护检查或改成 `git add -A`。
- 保留单一发布者锁，避免两个finalizer同时提交推送。
- 已运行Python进程不会自动加载修改后的源码。若旧监督器已失败，保留失败并用新tag执行发布尾部；若仍等待，可在核对身份后仅接管监督职责。不得重启、终止六项模型或原OOC。
- 本次脚本修复本身应有明确提交和运行版本绑定；不能把未冻结的工作树当作新测量来源。

## 2. 原任务的准确收尾范围

以下四个原完整核已有终态失败并已归档：checked P32/F1、router P32/F1、router P32/F0、router P8/F1。不要继续等它们。

快照时尚在运行的是：六项P8/F0完整batch模型、原P8/F0 OOC、排队的新GPU对照。执行时重新查询。

P8/F0的恢复和校准已经通过，无需重新做八个旧通过阶段、新hot8192/8193、四项boundary和十八项fixed10ns。

分别完成三条收尾链：

- **Native模型链：** 六项原模型→输出/工作/容量/ACK审计→归档→独立分支正常推送及远端SHA核对。
- **原OOC链：** 查询实际Vivado run和终态→路由合法性、setup/hold/pulse及资源→归档。不能由父PID存活或旧MCP快照推断run仍在运行。
- **新软件链：** 修正版worker→全部成功receipts→配对统计→预算更新→原始结果与分析归档推送。

现有native finalizer只等待native模型，不等待OOC；GPU watcher只负责分析，不保证最终归档推送。不得将其中一条完成写成整轮完成。

## 3. 保留软件对照的两个不同用途

计划为4个native输入×6个backend/representation＝24个测量组；每组3个独立进程，每进程1次预热＋3次正式测量。24不是进程总数。既定计划全部成功时，native72个执行进程，加91fixtures×2GPU表示，共254个执行receipts。

六组包括INF basic/compact CUDA、INF CPU，以及对应prepared-POP basic/compact CUDA和CPU control。测量范围保持 `RESIDENT_COMPLETE_BATCH_V2`，不改成E2或整个VPR process。

结果分别输出：

1. 本次同worker INF与本次control的配对比较；补3个process means及过程级配对比，无需增加测量。
2. 用于架构筛选的保守目标：历史合格prepared-POP与本次合格CUDA中较快者。

目前旧目标为BNN0.151799969444s、LSTM0.159888578444s。**如果INF CUDA更慢，不能因此放宽FPGA获胜目标**；同时保留INF同算法比较和最强软件比较。若更快，更新全部预算。

本机CPU 3.81462→4.56544s及3.70693→4.41971s为并发工作环境下的负结果，不能冒充H100 worker配对结论。新INF CUDA增加proposal归零，仍全节点commit扫描；其快慢须实测。

## 4. 本轮已学到什么

### 4.1 真实容量已经测清，4K总容量并非唯一问题

| 完整输入 | BNN | LSTM |
|---|---:|---:|
| 全batch touched4 lines |118,725,942|121,154,080|
| 单wave全局touched4峰值 |212,889|215,188|
| 每owner峰值 |6,745|6,784|
| 每subbank峰值 |3,383|3,401|
| 4-way/1024-set实际evictions |15,588,763|15,023,242|
| 全batch distinct spilled lines之和 |9,097,564|9,027,483|

每subbank4096 entries的总容量大于已测最大不同line数，但set冲突仍可驱逐。不能把“3401<4096”解释为零spill。现有hit约89.8%，继续把研究简单表述为提高一个很低的命中率已经不准确。

### 4.2 微核是合法路由后的setup失败

实际微核已合法路由10,167条nets，routing errors为0。5ns时WNS−6.048ns，hold+0.025ns，pulse+1.958ns。实际资源7013 LUT、1776 FF、66 RAMB36、10 RAMB18、0 URAM。

最坏路径为 `last_way_reg → forwarding/way选择 → sector/pair比较 → RAM DIN`，data delay10.754ns，其中route9.180ns（85.364%），17级逻辑。此模块接收已生成的candidate pair，并不做FP32加法。不得通过降低数值精度或改加法器来解释这条路径。

当前每subbank有四份1024×292bit RAM，一次读出全部四ways的1168bits，再在一拍里选way、选sector、做min并写回。64subbanks直接复制需要2272个BRAM36等价块，超过2016；这是当前组织的复制失败，不能推广成所有存储映射都不可行。

当前裸微OOC还有未约束input/output delay。下一版应用真实寄存接口wrapper或明确接口约束；内部setup通过与完整接口/全核资格分别记录。不能用WNS简单反算一个频率后直接赋予资格。

### 4.3 单独压缩scratch还不够

当前flush-all必要界约0.266757/0.270322s。hypothetical resident-direct hybrid的必要界为0.153780/0.155293s，且尚未包含CSR、POP、初始化等成本。

按现有逐wave计数复算，只把scratch从64B改为32B并让第一次spill免读旧值，条件界变为0.152209/0.153762s（P32、gap1、假设200MHz）。BNN仍慢于旧GPU目标，且额外成本未计。因此不要把“scratch压缩”独立当作足够胜出的方案。

## 5. 唯一建议推进的新候选：同时重排物理RAM与逻辑状态

先做下述三个模块/表示的有限验证，不直接复制完整核。

### 5.1 BRAM metadata＋flat URAM payload

保持原4-way/1024-set、4096 entries/subbank及替换规则：

- BRAM保存tag＋mask，四ways只并查小metadata。
- payload以 `{way,set}` 形成12bit slot地址，展平为4096×256bits。
- 四个64bit sectors分别放四条4096×72 URAM列；普通hit只访问对应sector，evict/flush再读取四个sectors。
- 64subbanks payload组织约256 URAM；full tag/mask与occupied列表粗估约352 BRAM36 equivalent。此数不含其余系统，也不是综合证明。

分级完成tag读取、way选择/reservation、payload读取、pair归约和writeback。增加流水后，原单项last_write转发不再足够；有限scoreboard必须覆盖全部在途阶段。

重点处理同line、同set miss争用、同slot不同sector、victim尚未退休、fragment背压及flush。metadata reservation和commit不能隐含变成每candidate两次RAM写；可用有限shadow reservation或显式串行化，并记录真实服务率。

目标是独立无冲突hit的II=1，不预先承诺所有冲突下均II=1。只使用真实1R/1W或已实现的等价端口服务，不凭双口声称2个RMW/周期。

### 5.2 Canonical label与pending分离，并验证17bit pending

当前 `node_state.sv` 把label64、pending32、flags32组成128bit record；一条32B外存事务只装两个节点。

在当前SHIFT20合同及可达状态中，有一个可验证不变量：

```text
pending.present == 1  =>  pending.bucket12 == canonical_label[63:52]
```

因此，POP/COMMIT已经读取label时，可以从label恢复bucket，只片上保存：

```text
present:1 + version:16 = 17 bits/node
```

先为旧状态与新表示写明确双向映射和逐操作语义核对：

| 操作 | 新表示必须保持的行为 |
|---|---|
| 初始化 | label=INF，P=0，V=0 |
| SEED | label=0，P=1，V=1 |
| 无效POP | 不改变状态 |
| 有效POP | 检查P、V、label-derived bucket后，**P和V全部清零**，返回旧label |
| 不改善COMMIT | 与原实现一致拒绝/无变化 |
| 改善且P=1、仍在同bucket | 更新label，保持V，不重复append |
| 改善且P=0或迁移bucket | 更新label、置P=1、V按原16bit模加1，发布对应目录事件 |

可达状态还满足P=0时V=0；原pending32应重建为 `P ? {3'b0,1'b1,V,old_label[63:52]} : 32'b0`。重建旧记录及比较同bucket均必须使用同一逻辑时刻的旧label。当前单调bucket迁移和POP清零使自然可达轨迹不会触及16bit回绕；仍保留原位宽和模加规则，并用构造的V=0xffff位级输入检查编码一致性，不能以V=0替代present判定。MARK/CLEAR不能简单丢弃：新结构要以最终唯一归约、有限enumeration和一次commit替代它们的去重功能。

数据组织：

- 外存canonical label为64bit pair，4节点/32B；不保留一份仍有原成本的128bit canonical镜像。
- pending每4节点为68bit，放一个72bit URAM字。
- MAX_N=2^22且64subbanks时，每subbank16384个pending words，需4个4K×72 URAM，总256个。这里是ECC关闭的72bit数据组织；若改变ECC合同需重算。
- payload256 URAM＋pending256 URAM＋目前既有288 URAM列表，粗略合计800 URAM，小于960，但尚未包含全部控制/其他存储，也没有布局资格。逐模块重建完整账本，防止重复计入或遗漏。
- 超出MAX_N显式拒绝或经过验证的有限fallback；不得隐藏超容量图。

最重要的新依赖：四个节点共享一个68bit pending word，对不同node的并发更新也会丢更新。scoreboard/forwarding以pending-word地址为粒度。17bit字段不天然对齐URAM字节写使能；采用整68bit word RMW或经过验证的合并更新，不能假设任意17bit独立写口。外部label、片上P/V、目录发布必须有统一的逻辑退休点和wave fence，不能让POP观察到新label＋旧P/V，或相反。

从已测计数看，这一布局在最终读写阶段可少约117,068,801/119,574,816个32B事务，即3.746/3.826GB。它改变的是finalize的主要state流量；实际收益仍需包含新pending服务及依赖。

### 5.3 32B scratch＋有限spill状态＋resident-direct finalization

四个pair的payload恰好32B，line地址由索引隐含。将初始化/有效状态放到有限片上位图或明确元数据，不再每片段都读取/写回一个64B record。

- 一个wave内某line首次spill：构造完整32B payload，未触达sectors填INF；只写，不读未初始化scratch。
- 后续spill：对完整pair做32B read＋32B write归约。
- 片上spill-valid map容量明确，清零/epoch和端口服务计入。
- 在首个写ACK前到来的同line片段必须等待或转发；不能重复执行first-write覆盖已有最小值。
- wave尾未spill过的resident行直接参与label比较，不强制写到scratch再读回。
- 已spill且仍resident的行，合并resident＋scratch后只提交一次；该交集全batch分别6,346,584/6,353,064行，不能漏算或重复提交。
- 每wave每subbank distinct spilled峰值为1028/965，因此1024-entry spill列表不足覆盖BNN；选择2048等有限容量必须有overflow测试和完整账本。
- scratch和外部枚举列表竞争有限外存端口/credits；pending与位图使用各自有限片上RAM端口，通过背压影响流水，不重复计为HBM流量。增加subbank不增加HBM带宽。当前复算保留外部spilled-ID列表读写；若实现改为片上2048-entry列表，需重新记录实际片上服务和资源，不同时收取不存在的外部列表事务。

## 6. 新候选的预算只说明值得有限验证

基于现有逐wave计数、P32/gap1、假设200MHz，32B first-write scratch＋packed64 label＋on-chip pending的有限分阶段条件界为：

| 条件推导 | BNN | LSTM |
|---|---:|---:|
| expansion＋finalize必要周期 |26,895,847|27,160,652|
| 加label/pending初始化与spill位图清理 |28,731,128|29,025,954|
| 对应假设时间 |0.143656s|0.145130s|
| 相对旧GPU目标的剩余时间 |约8.1ms|约14.8ms|

这些不是新架构模拟，也不是RTL结果。它们假设已归档的候选顺序与计数，尚缺实际CSR/POP前端的服务停顿、完整仲裁、RAW、FIFO、目录、ACK和router成本。改变仲裁可能改变替换与spill计数，必须重新测。

按保留旧CSR/metadata流量、每valid/stale POP一次32B label读等假设补账，总内部字节约25.184/25.680GB；P32/gap1预算尚有空间，P32/gap2仍不足。总字节能放入预算也不代表这些访问能够全部与计算重叠。

pending全量初始化不能免费：64banks并行每bank一word/cycle时，40samples需655,360cycles；上述初始化项采用label初始化与pending清零能够真实并行的条件。spill map每bank256个64bit word清零也已计入；若端口实际不能按此服务，更新成本。

新GPU对照可能继续收紧目标。若改变目标核频率，先固定外部服务的纳秒合同再换算cycle，不能同时免费提升外存带宽。必要界未通过的配置停止完整扩展，但继续完成独立已授权的收尾和软件任务。

## 7. 具体推进与停止条件

### S1：修脚本、收齐原结果

先完成第1–3节；不等待GPU排队才修worker，不重做旧校准，不把监督器退出当全部交付。

### S2：证明pending映射、完善完整预算

- 在现有软件/RTL状态操作参考上验证17bit不变量与语义，覆盖version0、seed、有效/无效POP、同桶/换桶改善；65535→0作为构造的位级注入测试，不宣称自然轨迹发生回绕。
- 以完整BNN/LSTM40跟踪不变量与重建旧pending32，核对全部输出、工作集合及native身份。
- 原FIFO/目录/容量边界继续保留；不能只测试顺序无冲突操作。
- 重新实现有限packed表示的流量/周期模型，纳入scratch/bitmap/pending/label/目录、清零、初始化、输出与ACK；固定模型和输入身份。
- 更新同worker软件对照后，重新判断是否有足够预算承担遗漏项，不以乐观下界的微小余量宣布成功。

### S3：只做一个有区分力的微原型

在分离tag/URAM payload的两-subbank单元中加入有限pending-word服务和scratch协议边界，至少覆盖：

- 全流水深度的连续同line更新、同set miss/victim竞争；
- 同pending-word不同节点并发POP/COMMIT请求；
- 首次spill与未ACK的后继片段、反序ACK及背压；
- resident与spill交集只commit一次；
- 恰好容量/容量+1、spill list满、两个连续wave无reset；
- 构造version wrap位级测试时不能将V=0误判absent；
- 所有接受/退休/fragment/commit计数守恒及最终整pair输出差分。

检查综合实际推断的BRAM/URAM类型、端口和延迟。应用有约束寄存接口做实际OOC；若失败，按新最坏路径做一项针对性修改，不做大量directive扫描。旧单项last_write转发和旧微核频率均不能继承。

### S4：满足条件才完整集成

只有完整有限服务预算和真实微原型都支持，才做32-owner/64-subbank全拓扑RTL校准、完整40sample模型和完整核OOC。禁止把两-subbank回放所有owner ID的stress当作完整router校准。

如果只是RAM与局部时序改善，而完整性能预算仍失败，归档该物理改进和明确失败原因；不继续直接复制同一失败结构。不得为了预定排序降低软件对照、放宽时间范围或将模型预测改名实测。

## 8. 最小交付与论文口径

- 修正版worker/source manifest、构建preflight、明确job/run-tag绑定和配对统计。
- 修正版发布监督器及六模型、OOC、GPU三条独立终态/归档/远端核对。
- `pending17_invariant`证明与原始差分结果。
- 新布局完整有限资源和周期账、条件失败点；原始trace复算脚本或明确入口。
- 若S3开展：真实RTL/testbench、有限服务、差分、持续退休率、实际资源及有约束OOC。
- 研究报告明确哪些是源码推导、原归档复算、新功能实验、新RTL实验、OOC结果和未完成项。

可以把方法主线写成：利用ALT波次语义延迟旧label比较；利用pending与label之间的可达状态不变量去除冗余bucket；将标签、队列控制与片上归约按访问方式拆开；用有限spill与原子退休保证完整输入正确性。是否形成论文性能贡献，取决于后续同范围完整结果；目前不能声称超过软件，也不声称STRICT等价。

## 9. 依据

所有项目链接固定到审阅SHA，避免分支继续前进后混淆：

- [续实验报告](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/blob/5af99087a9d7055d468cc5269326d985b911919d/docs/lookahead_fpga_sparse_stream_r2_continuation.md)
- [GPU worker](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/blob/5af99087a9d7055d468cc5269326d985b911919d/accel/lookahead/fpga_sparse_stream_r2/sim/gpu_private_inf_worker.py)
- [Native finalizer](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/blob/5af99087a9d7055d468cc5269326d985b911919d/accel/lookahead/fpga_sparse_stream_r2/sim/finalize_recovered_native.py)
- [Observer](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/blob/5af99087a9d7055d468cc5269326d985b911919d/accel/lookahead/fpga_sparse_stream_r2/sim/observe_continuation.py)
- [当前微核](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/blob/5af99087a9d7055d468cc5269326d985b911919d/accel/lookahead/fpga_sparse_stream_r2/rtl/wave_inf_bank.sv)
- [原node-state操作语义](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/blob/5af99087a9d7055d468cc5269326d985b911919d/accel/lookahead/fpga_sparse_stream_r2/rtl/node_state.sv)
- [原条件预算脚本](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/blob/5af99087a9d7055d468cc5269326d985b911919d/accel/lookahead/fpga_sparse_stream_r2/sim/analyze_wave_accumulator.py)
- [微OOC终态](https://github.com/GRYYYYYYY/3D_FPGA_Interconnects/blob/5af99087a9d7055d468cc5269326d985b911919d/results/fpga_sparse_stream_r2_20261112/evidence_snapshot/completed_micro_ooc_continuation2155/timing/wave_inf_micro_ram_d_5ns_recovery2/review.json)
- [AMD UG573 UltraRAM组织](https://docs.amd.com/r/en-US/ug573-ultrascale-memory-resources/UltraRAM-Summary)
- [AMD UG573 端口操作](https://docs.amd.com/r/en-US/ug573-ultrascale-memory-resources/Dual-Port-SRAM-Array-Operations)

附包中的 `derived_layout_screen.json` 是对既有逐wave计数的只读算术复算；不构成新硬件实验、完整模型校准或频率资格。

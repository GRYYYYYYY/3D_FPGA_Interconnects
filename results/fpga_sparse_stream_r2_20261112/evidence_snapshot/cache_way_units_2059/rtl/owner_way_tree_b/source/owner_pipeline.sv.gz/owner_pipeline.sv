`timescale 1ns/1ps
// Elastic synchronous-RAM hit pipeline: tag/read of request k+1 overlaps
// whole-line RMW/event publication of k. Miss/fill/eviction credits are finite.
module sparse_owner_pipe #(parameter OWNER_BITS=3,REQUEST_STAGE=0)(input wire clk,rst,iv,output wire ir,input wire [31:0] node,
 input wire [63:0] pair,input wire fence,output reg fence_done,
 output wire update_valid,input wire update_ready,output wire [31:0] update_line,output wire [3:0] update_mask,
 output reg mem_valid,input wire mem_ready,output reg mem_write,output reg [31:0] mem_line,
 output reg [5:0] mem_id,output reg [255:0] mem_data,
 input wire rsp_valid,output wire rsp_ready,input wire [5:0] rsp_id,input wire [255:0] rsp_data,
 output wire idle,output reg error,output reg [31:0] accepted,retired,merges,hits,misses,raw_stall,
 output reg [5:0] mshr_peak,output reg [4:0] dirty_peak);
 localparam [63:0] INF=64'h7f8000007f800000;
 wire qv,qr,fifo_ir,rv,rr;wire [95:0] qd;wire [261:0] rd;wire [6:0] qc,rc;
 sparse_fifo #(.WIDTH(96),.OUTPUT_STAGE(REQUEST_STAGE)) request_fifo(clk,rst,iv&&!fence,fifo_ir,{node,pair},qv,qr,qd,qc);
 sparse_fifo #(.WIDTH(262)) response_fifo(clk,rst,rsp_valid,rsp_ready,{rsp_id,rsp_data},rv,rr,rd,rc);
 assign ir=fifo_ir&&!fence;
 wire event_v,event_r;wire [35:0] event_data,event_out;wire [6:0] event_count;
 sparse_fifo #(.WIDTH(36)) event_fifo(clk,rst,event_v,event_r,event_data,update_valid,update_ready,event_out,event_count);
 assign {update_line,update_mask}=event_out;
 (* ram_style="block" *) reg [255:0] data_ram[0:127];
 reg [31:0] tags[0:127];reg [127:0] valid,dirty,busy;reg [1:0] replacement[0:31];
 reg [31:0] ml[0:31];
 (* ram_style="distributed" *) reg [31:0] mcount[0:31];
 reg [6:0] slot_for_miss[0:31];
 (* ram_style="distributed" *) reg [255:0] mc[0:31];reg [31:0] mv,ms,mg;
 reg [31:0] wl[0:15];(* ram_style="block" *) reg [255:0] wb[0:15];reg [15:0] wv,ws,wg;reg [3:0] swrite;
 reg sv,skind,sdirty;reg [6:0] sslot;reg [31:0] snode,sline,evict_line;reg [63:0] spair;reg [4:0] smiss;
 reg [255:0] ram_q,last_data;reg [6:0] last_slot;reg last_valid;
 reg flushing;reg [7:0] flush_index;reg command_turn;
 wire [31:0] qline={2'b0,qd[95:66]};
 wire signed [31:0] hit,victim;integer count_m,count_w;
 wire signed [31:0] matching,fm,fw,issue_m,issue_w;
 reg [15:0] wait_write[0:31];wire [15:0] allocation_wait;
 wire write_ack=rv&&rr&&rd[261];
 wire [15:0] ack_mask=write_ack?(16'b1<<rd[259:256]):16'b0;
 for(genvar j=0;j<16;j=j+1)begin:write_dependencies
  assign allocation_wait[j]=wv[j]&&wl[j]==qline&&!ack_mask[j];
 end
 // Balanced bit selection preserves exact low-ID issue/free priority and
 // the old high-ID matching priority. No linear 32-entry priority cascade.
 function automatic [5:0] first32(input [31:0] bits);
  reg [31:0] x;reg [4:0] index;
  begin x=bits;index=0;
   if(x[15:0]==0)begin index[4]=1;x=x>>16;end
   if(x[7:0]==0)begin index[3]=1;x=x>>8;end
   if(x[3:0]==0)begin index[2]=1;x=x>>4;end
   if(x[1:0]==0)begin index[1]=1;x=x>>2;end
   if(!x[0])index[0]=1;
   first32={|bits,index};
  end
 endfunction
 wire [31:0] issue_bits,match_reverse;wire [15:0] write_bits=wv&wg&~ws;
 for(genvar k=0;k<32;k=k+1)begin:selection_bits
  assign issue_bits[k]=mv[k]&&mg[k]&&!ms[k]&&wait_write[k]==0;
  assign match_reverse[31-k]=mv[k]&&ml[k]==qline;
 end
 wire [5:0] sel_m=first32(issue_bits),sel_w=first32({16'b0,write_bits});
 wire [5:0] free_m=first32(~mv),free_w=first32({16'b0,~wv});
 wire [5:0] match_id=first32(match_reverse);
 assign issue_m=sel_m[5]?{27'b0,sel_m[4:0]}:32'hffffffff;
 assign issue_w=sel_w[5]?{27'b0,sel_w[4:0]}:32'hffffffff;
 assign fm=free_m[5]?{27'b0,free_m[4:0]}:32'hffffffff;
 assign fw=free_w[5]?{27'b0,free_w[4:0]}:32'hffffffff;
 assign matching=match_id[5]?32'd31-{27'b0,match_id[4:0]}:32'hffffffff;
 wire [4:0] lookup_set=qline[OWNER_BITS+:5];
 wire [3:0] way_matches,way_available,way_invalid;
 wire hit_valid,victim_valid;wire [1:0] hit_way,victim_way;
 for(genvar w=0;w<4;w=w+1)begin:parallel_cache_ways
  wire [6:0] slot={2'(w),lookup_set};
  assign way_matches[w]=valid[slot]&&!busy[slot]&&tags[slot]==qline;
  assign way_available[w]=!busy[slot]&&!(sv&&sslot==slot);
  assign way_invalid[w]=way_available[w]&&!valid[slot];
 end
 r2_cache_way_select way_select(way_matches,way_available,way_invalid,
  replacement[lookup_set],hit_valid,hit_way,victim_valid,victim_way);
 assign hit=hit_valid?{25'b0,hit_way,lookup_set}:32'hffffffff;
 assign victim=victim_valid?{25'b0,victim_way,lookup_set}:32'hffffffff;
 always @*begin
  count_m=0;count_w=0;
  for(integer i=0;i<32;i=i+1)if(mv[i])count_m=count_m+1;
  for(integer i=0;i<16;i=i+1)if(wv[i])count_w=count_w+1;
 end
 wire [255:0] base_data=last_valid&&last_slot==sslot?last_data:ram_q;
 reg [255:0] hit_data,fill_data;reg [3:0] hit_mask,fill_mask;
 always @*begin
  hit_data=base_data;hit_mask=0;
  if(spair<base_data[snode[1:0]*64+:64])begin hit_data[snode[1:0]*64+:64]=spair;hit_mask[snode[1:0]]=1;end
  fill_data=rd[255:0];fill_mask=0;
  for(integer j=0;j<4;j=j+1)if(mc[rd[260:256]][j*64+:64]<rd[j*64+:64])begin fill_data[j*64+:64]=mc[rd[260:256]][j*64+:64];fill_mask[j]=1;end
 end
 wire advance=!sv||(skind?1'b1:(hit_mask==0||event_r));
 wire fill_wait=rv&&!rd[261];
 wire fill_take=fill_wait&&!sv&&(fill_mask==0||event_r);
 assign rr=rd[261]||(!sv&&(fill_mask==0||event_r));
 assign qr=!flushing&&!fill_wait&&advance&&(matching>=0||hit>=0||(fm>=0&&victim>=0&&(!dirty[victim]||fw>=0)));
 wire dispatch=qv&&qr;
 wire hit_dispatch=dispatch&&matching<0&&hit>=0;
 wire miss_dispatch=dispatch&&matching<0&&hit<0;
 // Allocation and merge are mutually exclusive: expose one whole-word write
 // port. Separate partial/nonpartial NBA writes prevented RAM inference.
 wire merge_dispatch=dispatch&&matching>=0;
 wire candidate_we=!rst&&(miss_dispatch||merge_dispatch);
 wire [4:0] candidate_wa=miss_dispatch?fm[4:0]:matching[4:0];
 reg [255:0] candidate_wd;
 always @*begin
  candidate_wd=miss_dispatch?{4{INF}}:mc[matching[4:0]];
  if(miss_dispatch||qd[63:0]<candidate_wd[qd[65:64]*64+:64])
   candidate_wd[qd[65:64]*64+:64]=qd[63:0];
 end
 always @(posedge clk)if(candidate_we)begin
  mc[candidate_wa]<=candidate_wd;
  mcount[candidate_wa]<=miss_dispatch?32'd1:mcount[matching[4:0]]+32'd1;
 end
 wire flush_dispatch=flushing&&flush_index<128&&dirty[flush_index[6:0]]&&advance&&fw>=0;
 wire ram_re=hit_dispatch||miss_dispatch||flush_dispatch;
 wire [6:0] ram_ra=flush_dispatch?flush_index[6:0]:hit_dispatch?hit[6:0]:victim[6:0];
 wire hit_write=sv&&!skind&&advance&&hit_mask!=0;
 wire ram_we=hit_write||fill_take;
 wire [6:0] ram_wa=fill_take?slot_for_miss[rd[260:256]]:sslot;
 wire [255:0] ram_wd=fill_take?fill_data:hit_data;
 assign event_v=hit_write||(fill_take&&fill_mask!=0);
 assign event_data=fill_take?{ml[rd[260:256]],fill_mask}:{sline,hit_mask};
 assign idle=!sv&&!flushing&&qc==0&&!qv&&rc==0&&!rv&&mv==0&&wv==0&&!mem_valid&&event_count==0&&!update_valid;
 always @(posedge clk)begin
  if(ram_re)ram_q<=data_ram[ram_ra];
  if(ram_we)data_ram[ram_wa]<=ram_wd;
  if(rst)begin sv<=0;valid<=0;dirty<=0;busy<=0;mv<=0;ms<=0;mg<=0;wv<=0;ws<=0;wg<=0;mem_valid<=0;fence_done<=0;flushing<=0;flush_index<=0;last_valid<=0;error<=0;accepted<=0;retired<=0;hits<=0;misses<=0;merges<=0;raw_stall<=0;mshr_peak<=0;dirty_peak<=0;command_turn<=0;
   for(integer i=0;i<32;i=i+1)replacement[i]<=0;
  end else begin
   if(write_ack)for(integer i=0;i<32;i=i+1)wait_write[i]<=wait_write[i]&~ack_mask;
   if(iv&&ir)accepted<=accepted+1;
   if(qv&&!qr)raw_stall<=raw_stall+1;
   if(count_m>mshr_peak)mshr_peak<=count_m;if(count_w>dirty_peak)dirty_peak<=count_w;
   if(ram_we)begin last_valid<=1;last_slot<=ram_wa;last_data<=ram_wd;end
   if(!mem_valid||mem_ready)begin
    mem_valid<=0;
    if(issue_w>=0&&(issue_m<0||!command_turn))begin mem_valid<=1;mem_write<=1;mem_line<=wl[issue_w];mem_id<=32+issue_w;mem_data<=wb[issue_w];ws[issue_w]<=1;command_turn<=1;end
    else if(issue_m>=0)begin mem_valid<=1;mem_write<=0;mem_line<=ml[issue_m];mem_id<=issue_m;mem_data<=0;ms[issue_m]<=1;command_turn<=0;end
   end
   if(rv&&rr&&rd[261])begin if(rd[261:256]>=48||!wv[rd[259:256]]||!ws[rd[259:256]])error<=1;else begin wv[rd[259:256]]<=0;ws[rd[259:256]]<=0;wg[rd[259:256]]<=0;end end
   if(fill_take)begin
    if(!mv[rd[260:256]]||!ms[rd[260:256]])error<=1;
    valid[slot_for_miss[rd[260:256]]]<=1;busy[slot_for_miss[rd[260:256]]]<=0;dirty[slot_for_miss[rd[260:256]]]<=fill_mask!=0;
    mv[rd[260:256]]<=0;ms[rd[260:256]]<=0;mg[rd[260:256]]<=0;retired<=retired+mcount[rd[260:256]];
   end
   if(advance)begin
    sv<=0;
    if(sv)begin
     if(!skind)begin retired<=retired+1;if(hit_mask!=0)dirty[sslot]<=1;end
     else begin
      if(sdirty)begin wb[swrite]<=base_data;wg[swrite]<=1;end
      if(!flushing)mg[smiss]<=1;
     end
    end
    if(hit_dispatch)begin sv<=1;skind<=0;sslot<=hit;snode<=qd[95:64];sline<=qline;spair<=qd[63:0];hits<=hits+1;end
    if(miss_dispatch)begin
     sv<=1;skind<=1;sslot<=victim;sdirty<=dirty[victim];evict_line<=tags[victim];smiss<=fm;
     if(dirty[victim])begin swrite<=fw;wv[fw]<=1;ws[fw]<=0;wg[fw]<=0;wl[fw]<=tags[victim];end
     wait_write[fm]<=allocation_wait;
     mv[fm]<=1;ms[fm]<=0;mg[fm]<=0;ml[fm]<=qline;slot_for_miss[fm]<=victim;
     valid[victim]<=0;dirty[victim]<=0;busy[victim]<=1;tags[victim]<=qline;replacement[qline[OWNER_BITS+:5]]<=victim[6:5]+1;misses<=misses+1;
    end
    if(flush_dispatch)begin swrite<=fw;wv[fw]<=1;ws[fw]<=0;wg[fw]<=0;wl[fw]<=tags[flush_index[6:0]];sv<=1;skind<=1;sslot<=flush_index[6:0];sdirty<=1;evict_line<=tags[flush_index[6:0]];dirty[flush_index[6:0]]<=0;flush_index<=flush_index+1;end
   end
   if(merge_dispatch)merges<=merges+1;
   if(!fence)fence_done<=0;
   if(fence&&!fence_done&&!flushing&&idle)begin flushing<=1;flush_index<=0;end
   if(flushing&&flush_index<128&&!dirty[flush_index[6:0]])flush_index<=flush_index+1;
   if(flushing&&flush_index==128&&!sv&&wv==0&&!mem_valid&&rc==0&&!rv&&event_count==0&&!update_valid)begin flushing<=0;fence_done<=1;end
  end
 end
`ifndef SYNTHESIS
 always @(posedge clk)if(!rst)begin
  for(integer i=0;i<32;i=i+1)for(integer j=0;j<16;j=j+1)
   if(mv[i]&&(wait_write[i][j] !== (wv[j]&&wl[j]==ml[i])))
    $fatal(1,"write dependency differs from address-based guard: mshr=%0d slot=%0d",i,j);
 end
`endif
endmodule

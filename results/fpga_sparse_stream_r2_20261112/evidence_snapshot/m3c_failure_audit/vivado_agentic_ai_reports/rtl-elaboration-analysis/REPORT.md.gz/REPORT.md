# RTL elaboration analysis — pipe_full_c

8 ERROR + 99 WARNING rows. Root failure: directory multiple procedural write sites prevent RAM inference. Labels/pending and member-next port inference need the same structural repair. No memory dissolve-limit override will be used. All 107 non-INFO occurrences are covered below; rows repeating across eight bank instances are grouped.

The supplied skill is used in log-analysis mode. Its document-search tool is not installed; no external documentation was invented. The failed source snapshot remains immutable.

|ID|Count|
|---|---:|
|6014|55|
|3936|8|
|4767|36|
|3391|8|

### Synth 8-6014: Unused sequential element closed_mark_reg was removed.

File: [bank_pipeline.sv:84](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/bank_pipeline.sv:84)

Reviewed parameter-dependent dead closed-scan state or procedural temporary/unused payload register. Do not add KEEP/DONT_TOUCH. Recheck after resolving root RAM errors; removal does not itself prove missing functionality.

|CSV S.No|Message|
|---|---|
|63|Unused sequential element closed_mark_reg was removed.|
|81|Unused sequential element closed_mark_reg was removed.|
|90|Unused sequential element closed_mark_reg was removed.|
|99|Unused sequential element closed_mark_reg was removed.|
|108|Unused sequential element closed_mark_reg was removed.|
|117|Unused sequential element closed_mark_reg was removed.|
|126|Unused sequential element closed_mark_reg was removed.|
|135|Unused sequential element closed_mark_reg was removed.|

Problematic context:
```diff
-   label_q<=labels[read_node];pending_q<=pending[read_node];if(!POP_REDUCE)closed_q<=closed[closed_rd[NA-1:0]];
-   if(rst)begin p0v<=0;p1v<=0;last_dir_valid<=0;has_bucket<=0;min_bucket<=0;init_busy<=0;init_sent<=0;init_acked<=0;context_valid<=0;context_sent<=0;context_ready<=0;commit_index<=0;mem_id<=0;state<=IDLE;done<=0;error<=0;pv<=0;close_valid<=0;ca<=0;mem_valid<=0;bitmap<=0;groups<=0;closed_mark<=0;closed_wr<=0;closed_rd<=0;free_count<=MC;member_peak<=0;active_count<=0;commit_count<=0;closed_count<=0;stale_count<=0;end else begin
-    ca<=0;
-    if(pool_iv&&!pool_ir)error<=1;if(pool_or&&!pool_ov)error<=1;
```
Recommended implementation / retained advisory context:
```diff
+   label_q<=labels[read_node];pending_q<=pending[read_node];if(!POP_REDUCE)closed_q<=closed[closed_rd[NA-1:0]];
+   if(rst)begin p0v<=0;p1v<=0;last_dir_valid<=0;has_bucket<=0;min_bucket<=0;init_busy<=0;init_sent<=0;init_acked<=0;context_valid<=0;context_sent<=0;context_ready<=0;commit_index<=0;mem_id<=0;state<=IDLE;done<=0;error<=0;pv<=0;close_valid<=0;ca<=0;mem_valid<=0;bitmap<=0;groups<=0;closed_mark<=0;closed_wr<=0;closed_rd<=0;free_count<=MC;member_peak<=0;active_count<=0;commit_count<=0;closed_count<=0;stale_count<=0;end else begin
+    ca<=0;
+    if(pool_iv&&!pool_ir)error<=1;if(pool_or&&!pool_ov)error<=1;
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
  label_q<=labels[read_node];pending_q<=pending[read_node];if(!POP_REDUCE)closed_q<=closed[closed_rd[NA-1:0]];
  if(rst)begin p0v<=0;p1v<=0;last_dir_valid<=0;has_bucket<=0;min_bucket<=0;init_busy<=0;init_sent<=0;init_acked<=0;context_valid<=0;context_sent<=0;context_ready<=0;commit_index<=0;mem_id<=0;state<=IDLE;done<=0;error<=0;pv<=0;close_valid<=0;ca<=0;mem_valid<=0;bitmap<=0;groups<=0;closed_mark<=0;closed_wr<=0;closed_rd<=0;free_count<=MC;member_peak<=0;active_count<=0;commit_count<=0;closed_count<=0;stale_count<=0;end else begin
   ca<=0;
   if(pool_iv&&!pool_ir)error<=1;if(pool_or&&!pool_ov)error<=1;
```
> The block can be copied into `bank_pipeline.sv` near line 84; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element closed_wr_reg was removed.

File: [bank_pipeline.sv:84](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/bank_pipeline.sv:84)

Reviewed parameter-dependent dead closed-scan state or procedural temporary/unused payload register. Do not add KEEP/DONT_TOUCH. Recheck after resolving root RAM errors; removal does not itself prove missing functionality.

|CSV S.No|Message|
|---|---|
|64|Unused sequential element closed_wr_reg was removed.|
|82|Unused sequential element closed_wr_reg was removed.|
|91|Unused sequential element closed_wr_reg was removed.|
|100|Unused sequential element closed_wr_reg was removed.|
|109|Unused sequential element closed_wr_reg was removed.|
|118|Unused sequential element closed_wr_reg was removed.|
|127|Unused sequential element closed_wr_reg was removed.|
|136|Unused sequential element closed_wr_reg was removed.|

Problematic context:
```diff
-   label_q<=labels[read_node];pending_q<=pending[read_node];if(!POP_REDUCE)closed_q<=closed[closed_rd[NA-1:0]];
-   if(rst)begin p0v<=0;p1v<=0;last_dir_valid<=0;has_bucket<=0;min_bucket<=0;init_busy<=0;init_sent<=0;init_acked<=0;context_valid<=0;context_sent<=0;context_ready<=0;commit_index<=0;mem_id<=0;state<=IDLE;done<=0;error<=0;pv<=0;close_valid<=0;ca<=0;mem_valid<=0;bitmap<=0;groups<=0;closed_mark<=0;closed_wr<=0;closed_rd<=0;free_count<=MC;member_peak<=0;active_count<=0;commit_count<=0;closed_count<=0;stale_count<=0;end else begin
-    ca<=0;
-    if(pool_iv&&!pool_ir)error<=1;if(pool_or&&!pool_ov)error<=1;
```
Recommended implementation / retained advisory context:
```diff
+   label_q<=labels[read_node];pending_q<=pending[read_node];if(!POP_REDUCE)closed_q<=closed[closed_rd[NA-1:0]];
+   if(rst)begin p0v<=0;p1v<=0;last_dir_valid<=0;has_bucket<=0;min_bucket<=0;init_busy<=0;init_sent<=0;init_acked<=0;context_valid<=0;context_sent<=0;context_ready<=0;commit_index<=0;mem_id<=0;state<=IDLE;done<=0;error<=0;pv<=0;close_valid<=0;ca<=0;mem_valid<=0;bitmap<=0;groups<=0;closed_mark<=0;closed_wr<=0;closed_rd<=0;free_count<=MC;member_peak<=0;active_count<=0;commit_count<=0;closed_count<=0;stale_count<=0;end else begin
+    ca<=0;
+    if(pool_iv&&!pool_ir)error<=1;if(pool_or&&!pool_ov)error<=1;
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
  label_q<=labels[read_node];pending_q<=pending[read_node];if(!POP_REDUCE)closed_q<=closed[closed_rd[NA-1:0]];
  if(rst)begin p0v<=0;p1v<=0;last_dir_valid<=0;has_bucket<=0;min_bucket<=0;init_busy<=0;init_sent<=0;init_acked<=0;context_valid<=0;context_sent<=0;context_ready<=0;commit_index<=0;mem_id<=0;state<=IDLE;done<=0;error<=0;pv<=0;close_valid<=0;ca<=0;mem_valid<=0;bitmap<=0;groups<=0;closed_mark<=0;closed_wr<=0;closed_rd<=0;free_count<=MC;member_peak<=0;active_count<=0;commit_count<=0;closed_count<=0;stale_count<=0;end else begin
   ca<=0;
   if(pool_iv&&!pool_ir)error<=1;if(pool_or&&!pool_ov)error<=1;
```
> The block can be copied into `bank_pipeline.sv` near line 84; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element closed_rd_reg was removed.

File: [bank_pipeline.sv:84](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/bank_pipeline.sv:84)

Reviewed parameter-dependent dead closed-scan state or procedural temporary/unused payload register. Do not add KEEP/DONT_TOUCH. Recheck after resolving root RAM errors; removal does not itself prove missing functionality.

|CSV S.No|Message|
|---|---|
|65|Unused sequential element closed_rd_reg was removed.|
|83|Unused sequential element closed_rd_reg was removed.|
|92|Unused sequential element closed_rd_reg was removed.|
|101|Unused sequential element closed_rd_reg was removed.|
|110|Unused sequential element closed_rd_reg was removed.|
|119|Unused sequential element closed_rd_reg was removed.|
|128|Unused sequential element closed_rd_reg was removed.|
|137|Unused sequential element closed_rd_reg was removed.|

Problematic context:
```diff
-   label_q<=labels[read_node];pending_q<=pending[read_node];if(!POP_REDUCE)closed_q<=closed[closed_rd[NA-1:0]];
-   if(rst)begin p0v<=0;p1v<=0;last_dir_valid<=0;has_bucket<=0;min_bucket<=0;init_busy<=0;init_sent<=0;init_acked<=0;context_valid<=0;context_sent<=0;context_ready<=0;commit_index<=0;mem_id<=0;state<=IDLE;done<=0;error<=0;pv<=0;close_valid<=0;ca<=0;mem_valid<=0;bitmap<=0;groups<=0;closed_mark<=0;closed_wr<=0;closed_rd<=0;free_count<=MC;member_peak<=0;active_count<=0;commit_count<=0;closed_count<=0;stale_count<=0;end else begin
-    ca<=0;
-    if(pool_iv&&!pool_ir)error<=1;if(pool_or&&!pool_ov)error<=1;
```
Recommended implementation / retained advisory context:
```diff
+   label_q<=labels[read_node];pending_q<=pending[read_node];if(!POP_REDUCE)closed_q<=closed[closed_rd[NA-1:0]];
+   if(rst)begin p0v<=0;p1v<=0;last_dir_valid<=0;has_bucket<=0;min_bucket<=0;init_busy<=0;init_sent<=0;init_acked<=0;context_valid<=0;context_sent<=0;context_ready<=0;commit_index<=0;mem_id<=0;state<=IDLE;done<=0;error<=0;pv<=0;close_valid<=0;ca<=0;mem_valid<=0;bitmap<=0;groups<=0;closed_mark<=0;closed_wr<=0;closed_rd<=0;free_count<=MC;member_peak<=0;active_count<=0;commit_count<=0;closed_count<=0;stale_count<=0;end else begin
+    ca<=0;
+    if(pool_iv&&!pool_ir)error<=1;if(pool_or&&!pool_ov)error<=1;
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
  label_q<=labels[read_node];pending_q<=pending[read_node];if(!POP_REDUCE)closed_q<=closed[closed_rd[NA-1:0]];
  if(rst)begin p0v<=0;p1v<=0;last_dir_valid<=0;has_bucket<=0;min_bucket<=0;init_busy<=0;init_sent<=0;init_acked<=0;context_valid<=0;context_sent<=0;context_ready<=0;commit_index<=0;mem_id<=0;state<=IDLE;done<=0;error<=0;pv<=0;close_valid<=0;ca<=0;mem_valid<=0;bitmap<=0;groups<=0;closed_mark<=0;closed_wr<=0;closed_rd<=0;free_count<=MC;member_peak<=0;active_count<=0;commit_count<=0;closed_count<=0;stale_count<=0;end else begin
   ca<=0;
   if(pool_iv&&!pool_ir)error<=1;if(pool_or&&!pool_ov)error<=1;
```
> The block can be copied into `bank_pipeline.sv` near line 84; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-3936: Found unconnected internal register 'pending_q_reg' and it is trimmed from '32' to '29' bits.

File: [bank_pipeline.sv:58](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/bank_pipeline.sv:58)

Reviewed: only the 29 meaningful pending bits are consumed (valid, version, bucket). Upper three bits are reserved zero; trimming is semantically expected.

|CSV S.No|Message|
|---|---|
|66|Found unconnected internal register 'pending_q_reg' and it is trimmed from '32' to '29' bits.|
|84|Found unconnected internal register 'pending_q_reg' and it is trimmed from '32' to '29' bits.|
|93|Found unconnected internal register 'pending_q_reg' and it is trimmed from '32' to '29' bits.|
|102|Found unconnected internal register 'pending_q_reg' and it is trimmed from '32' to '29' bits.|
|111|Found unconnected internal register 'pending_q_reg' and it is trimmed from '32' to '29' bits.|
|120|Found unconnected internal register 'pending_q_reg' and it is trimmed from '32' to '29' bits.|
|129|Found unconnected internal register 'pending_q_reg' and it is trimmed from '32' to '29' bits.|
|138|Found unconnected internal register 'pending_q_reg' and it is trimmed from '32' to '29' bits.|

Problematic context:
```diff
-  wire [NA-1:0] read_node=select_context?context_index[ready_context]:idx;
-  wire p0append=!pending_q[28]||pending_q[11:0]!=p0value[63:52];
-  wire publish=command==3&&p1v;
-  wire forwarded_dir=last_dir_valid&&last_dir_key==p1key;
```
Recommended implementation / retained advisory context:
```diff
+  wire [NA-1:0] read_node=select_context?context_index[ready_context]:idx;
+  wire p0append=!pending_q[28]||pending_q[11:0]!=p0value[63:52];
+  wire publish=command==3&&p1v;
+  wire forwarded_dir=last_dir_valid&&last_dir_key==p1key;
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
 wire [NA-1:0] read_node=select_context?context_index[ready_context]:idx;
 wire p0append=!pending_q[28]||pending_q[11:0]!=p0value[63:52];
 wire publish=command==3&&p1v;
 wire forwarded_dir=last_dir_valid&&last_dir_key==p1key;
```
> The block can be copied into `bank_pipeline.sv` near line 58; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-4767: Trying to implement RAM 'member_next_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.

File: [bank_pipeline.sv:20](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/bank_pipeline.sv:20)

Actionable: infer two separate clocked next-link RAM ports; new-entry write/POP read share port A, tail-link write uses port B. Allocator ensures tail and new IDs differ.

|CSV S.No|Message|
|---|---|
|67|Trying to implement RAM 'member_next_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|85|Trying to implement RAM 'member_next_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|94|Trying to implement RAM 'member_next_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|103|Trying to implement RAM 'member_next_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|112|Trying to implement RAM 'member_next_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|121|Trying to implement RAM 'member_next_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|130|Trying to implement RAM 'member_next_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|139|Trying to implement RAM 'member_next_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|

Problematic context:
```diff
-  (* ram_style="block" *) reg [63:0] directory[0:4095];
-  (* ram_style="block" *) reg [31:0] member_header[0:MC-1],member_next[0:MC-1];
-  reg [31:0] header_q,next_q;
-  wire pool_iv,pool_ir,pool_ov,pool_or;wire [MA-1:0] pool_in,pool_out;wire [MA:0] pool_count;
```
Recommended implementation / retained advisory context:
```diff
+ always @(posedge clk) begin
+   if(member_new_we) member_next[member_new_index] <= NIL;
+   else next_q <= member_next[pointer[MA-1:0]];
+ end
+ always @(posedge clk) begin
+   if(member_tail_we) member_next[member_tail_index] <= member_tail_next;
+ end
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
always @(posedge clk) begin
  if(member_new_we) member_next[member_new_index] <= NIL;
  else next_q <= member_next[pointer[MA-1:0]];
end
always @(posedge clk) begin
  if(member_tail_we) member_next[member_tail_index] <= member_tail_next;
end
```
> The block can be copied into `bank_pipeline.sv` near line 20; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-4767: Trying to implement RAM 'directory_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.

File: [bank_pipeline.sv:19](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/bank_pipeline.sv:19)

Actionable: initialization/seed, POP, and pipelined COMMIT assignments use distinct write sites. Multiplex enables/address/data before one synchronous write port per array. Keep one synchronous read port and existing explicit directory forwarding.

|CSV S.No|Message|
|---|---|
|68|Trying to implement RAM 'directory_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|86|Trying to implement RAM 'directory_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|95|Trying to implement RAM 'directory_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|104|Trying to implement RAM 'directory_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|113|Trying to implement RAM 'directory_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|122|Trying to implement RAM 'directory_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|131|Trying to implement RAM 'directory_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|140|Trying to implement RAM 'directory_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|

Problematic context:
```diff
-  (* ram_style="block" *) reg [31:0] pending[0:NC-1];
-  (* ram_style="block" *) reg [63:0] directory[0:4095];
-  (* ram_style="block" *) reg [31:0] member_header[0:MC-1],member_next[0:MC-1];
-  reg [31:0] header_q,next_q;
```
Recommended implementation / retained advisory context:
```diff
+ // Route every directory update through this single physical write port.
+ always @(posedge clk) begin
+   if(directory_we) directory[directory_wa] <= directory_wd;
+ end
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
// Route every directory update through this single physical write port.
always @(posedge clk) begin
  if(directory_we) directory[directory_wa] <= directory_wd;
end
```
> The block can be copied into `bank_pipeline.sv` near line 19; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-3391: Unable to infer a block/distributed RAM for 'directory_reg' because the memory pattern used is not supported. Failed to dissolve the memory into bits because the number of bits (262144) is too large. Use 'set_param synth.elaboration.rodinMoreOptions {rt::set_parameter dissolveMemorySizeLimit 262144}' to allow the memory to be dissolved into individual bits

File: [bank_pipeline.sv:19](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/bank_pipeline.sv:19)

Actionable: initialization/seed, POP, and pipelined COMMIT assignments use distinct write sites. Multiplex enables/address/data before one synchronous write port per array. Keep one synchronous read port and existing explicit directory forwarding.

|CSV S.No|Message|
|---|---|
|69|Unable to infer a block/distributed RAM for 'directory_reg' because the memory pattern used is not supported. Failed to dissolve the memory into bits because the number of bits (262144) is too large. Use 'set_param synth.elaboration.rodinMoreOptions {rt::set_parameter dissolveMemorySizeLimit 262144}' to allow the memory to be dissolved into individual bits|
|87|Unable to infer a block/distributed RAM for 'directory_reg' because the memory pattern used is not supported. Failed to dissolve the memory into bits because the number of bits (262144) is too large. Use 'set_param synth.elaboration.rodinMoreOptions {rt::set_parameter dissolveMemorySizeLimit 262144}' to allow the memory to be dissolved into individual bits|
|96|Unable to infer a block/distributed RAM for 'directory_reg' because the memory pattern used is not supported. Failed to dissolve the memory into bits because the number of bits (262144) is too large. Use 'set_param synth.elaboration.rodinMoreOptions {rt::set_parameter dissolveMemorySizeLimit 262144}' to allow the memory to be dissolved into individual bits|
|105|Unable to infer a block/distributed RAM for 'directory_reg' because the memory pattern used is not supported. Failed to dissolve the memory into bits because the number of bits (262144) is too large. Use 'set_param synth.elaboration.rodinMoreOptions {rt::set_parameter dissolveMemorySizeLimit 262144}' to allow the memory to be dissolved into individual bits|
|114|Unable to infer a block/distributed RAM for 'directory_reg' because the memory pattern used is not supported. Failed to dissolve the memory into bits because the number of bits (262144) is too large. Use 'set_param synth.elaboration.rodinMoreOptions {rt::set_parameter dissolveMemorySizeLimit 262144}' to allow the memory to be dissolved into individual bits|
|123|Unable to infer a block/distributed RAM for 'directory_reg' because the memory pattern used is not supported. Failed to dissolve the memory into bits because the number of bits (262144) is too large. Use 'set_param synth.elaboration.rodinMoreOptions {rt::set_parameter dissolveMemorySizeLimit 262144}' to allow the memory to be dissolved into individual bits|
|132|Unable to infer a block/distributed RAM for 'directory_reg' because the memory pattern used is not supported. Failed to dissolve the memory into bits because the number of bits (262144) is too large. Use 'set_param synth.elaboration.rodinMoreOptions {rt::set_parameter dissolveMemorySizeLimit 262144}' to allow the memory to be dissolved into individual bits|
|141|Unable to infer a block/distributed RAM for 'directory_reg' because the memory pattern used is not supported. Failed to dissolve the memory into bits because the number of bits (262144) is too large. Use 'set_param synth.elaboration.rodinMoreOptions {rt::set_parameter dissolveMemorySizeLimit 262144}' to allow the memory to be dissolved into individual bits|

Problematic context:
```diff
-  (* ram_style="block" *) reg [31:0] pending[0:NC-1];
-  (* ram_style="block" *) reg [63:0] directory[0:4095];
-  (* ram_style="block" *) reg [31:0] member_header[0:MC-1],member_next[0:MC-1];
-  reg [31:0] header_q,next_q;
```
Recommended implementation / retained advisory context:
```diff
+ // Route every directory update through this single physical write port.
+ always @(posedge clk) begin
+   if(directory_we) directory[directory_wa] <= directory_wd;
+ end
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
// Route every directory update through this single physical write port.
always @(posedge clk) begin
  if(directory_we) directory[directory_wa] <= directory_wd;
end
```
> The block can be copied into `bank_pipeline.sv` near line 19; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-4767: Trying to implement RAM 'labels_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.

File: [bank_pipeline.sv:17](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/bank_pipeline.sv:17)

Actionable: initialization/seed, POP, and pipelined COMMIT assignments use distinct write sites. Multiplex enables/address/data before one synchronous write port per array. Keep one synchronous read port and existing explicit directory forwarding.

|CSV S.No|Message|
|---|---|
|70|Trying to implement RAM 'labels_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|88|Trying to implement RAM 'labels_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|97|Trying to implement RAM 'labels_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|106|Trying to implement RAM 'labels_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|115|Trying to implement RAM 'labels_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|124|Trying to implement RAM 'labels_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|133|Trying to implement RAM 'labels_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|142|Trying to implement RAM 'labels_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|

Problematic context:
```diff
-  localparam [31:0] NIL=32'hffffffff;
-  (* ram_style="block" *) reg [63:0] labels[0:NC-1];
-  (* ram_style="block" *) reg [31:0] pending[0:NC-1];
-  (* ram_style="block" *) reg [63:0] directory[0:4095];
```
Recommended implementation / retained advisory context:
```diff
+ // Route every directory update through this single physical write port.
+ always @(posedge clk) begin
+   if(directory_we) directory[directory_wa] <= directory_wd;
+ end
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
// Route every directory update through this single physical write port.
always @(posedge clk) begin
  if(directory_we) directory[directory_wa] <= directory_wd;
end
```
> The block can be copied into `bank_pipeline.sv` near line 17; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-4767: Trying to implement RAM 'pending_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.

File: [bank_pipeline.sv:18](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/bank_pipeline.sv:18)

Actionable: initialization/seed, POP, and pipelined COMMIT assignments use distinct write sites. Multiplex enables/address/data before one synchronous write port per array. Keep one synchronous read port and existing explicit directory forwarding.

|CSV S.No|Message|
|---|---|
|71|Trying to implement RAM 'pending_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|89|Trying to implement RAM 'pending_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|98|Trying to implement RAM 'pending_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|107|Trying to implement RAM 'pending_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|116|Trying to implement RAM 'pending_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|125|Trying to implement RAM 'pending_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|134|Trying to implement RAM 'pending_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|
|143|Trying to implement RAM 'pending_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|

Problematic context:
```diff
-  (* ram_style="block" *) reg [63:0] labels[0:NC-1];
-  (* ram_style="block" *) reg [31:0] pending[0:NC-1];
-  (* ram_style="block" *) reg [63:0] directory[0:4095];
-  (* ram_style="block" *) reg [31:0] member_header[0:MC-1],member_next[0:MC-1];
```
Recommended implementation / retained advisory context:
```diff
+ // Route every directory update through this single physical write port.
+ always @(posedge clk) begin
+   if(directory_we) directory[directory_wa] <= directory_wd;
+ end
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
// Route every directory update through this single physical write port.
always @(posedge clk) begin
  if(directory_we) directory[directory_wa] <= directory_wd;
end
```
> The block can be copied into `bank_pipeline.sv` near line 18; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element desc_reg was removed.

File: [frontend.sv:33](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/frontend.sv:33)

Reviewed parameter-dependent dead closed-scan state or procedural temporary/unused payload register. Do not add KEEP/DONT_TOUCH. Recheck after resolving root RAM errors; removal does not itself prove missing functionality.

|CSV S.No|Message|
|---|---|
|72|Unused sequential element desc_reg was removed.|

Problematic context:
```diff
-    if(!emitv||emitr)begin emitv<=0;if(emit>=0)begin
-     desc=beat[emit][pos[emit][2:0]*32+:32];emitv<=1;emitdst<={4'b0,desc[27:0]};emitparent<=parent[emit];emitcost<=costs[desc[31:28]];candidates<=candidates+1;rr<=emit+1;
-     pos[emit]<=pos[emit]+1;
-     if(pos[emit]+1==last[emit])state[emit]<=FREE;else if(pos[emit][2:0]==7)state[emit]<=EDGE;
```
Recommended implementation / retained advisory context:
```diff
+    if(!emitv||emitr)begin emitv<=0;if(emit>=0)begin
+     desc=beat[emit][pos[emit][2:0]*32+:32];emitv<=1;emitdst<={4'b0,desc[27:0]};emitparent<=parent[emit];emitcost<=costs[desc[31:28]];candidates<=candidates+1;rr<=emit+1;
+     pos[emit]<=pos[emit]+1;
+     if(pos[emit]+1==last[emit])state[emit]<=FREE;else if(pos[emit][2:0]==7)state[emit]<=EDGE;
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
   if(!emitv||emitr)begin emitv<=0;if(emit>=0)begin
    desc=beat[emit][pos[emit][2:0]*32+:32];emitv<=1;emitdst<={4'b0,desc[27:0]};emitparent<=parent[emit];emitcost<=costs[desc[31:28]];candidates<=candidates+1;rr<=emit+1;
    pos[emit]<=pos[emit]+1;
    if(pos[emit]+1==last[emit])state[emit]<=FREE;else if(pos[emit][2:0]==7)state[emit]<=EDGE;
```
> The block can be copied into `frontend.sv` near line 33; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element a_reg was removed.

File: [frontend.sv:43](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/frontend.sv:43)

Reviewed parameter-dependent dead closed-scan state or procedural temporary/unused payload register. Do not add KEEP/DONT_TOUCH. Recheck after resolving root RAM errors; removal does not itself prove missing functionality.

|CSV S.No|Message|
|---|---|
|73|Unused sequential element a_reg was removed.|

Problematic context:
```diff
-      else if(row_valid&&row_tag==row_base+(node[fetch]>>2))begin
-       a=row_cache[node[fetch][1:0]*64+:64];pos[fetch]<=a[31:0];if(a[63:32]!=0)local_error<=1;
-       if(node[fetch][1:0]==3)state[fetch]<=ROW_NEXT;else begin b=row_cache[(node[fetch][1:0]+1)*64+:64];last[fetch]<=b[31:0];if(b[63:32]!=0||b<a)local_error<=1;state[fetch]<=a==b?FREE:EDGE;end
-      end else begin mem_valid<=1;mem_line<=row_base+(node[fetch]>>2);mem_id<={2'b00,fetch[1:0]};state[fetch]<=ROW_WAIT;row_beats<=row_beats+1;end
```
Recommended implementation / retained advisory context:
```diff
+      else if(row_valid&&row_tag==row_base+(node[fetch]>>2))begin
+       a=row_cache[node[fetch][1:0]*64+:64];pos[fetch]<=a[31:0];if(a[63:32]!=0)local_error<=1;
+       if(node[fetch][1:0]==3)state[fetch]<=ROW_NEXT;else begin b=row_cache[(node[fetch][1:0]+1)*64+:64];last[fetch]<=b[31:0];if(b[63:32]!=0||b<a)local_error<=1;state[fetch]<=a==b?FREE:EDGE;end
+      end else begin mem_valid<=1;mem_line<=row_base+(node[fetch]>>2);mem_id<={2'b00,fetch[1:0]};state[fetch]<=ROW_WAIT;row_beats<=row_beats+1;end
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
     else if(row_valid&&row_tag==row_base+(node[fetch]>>2))begin
      a=row_cache[node[fetch][1:0]*64+:64];pos[fetch]<=a[31:0];if(a[63:32]!=0)local_error<=1;
      if(node[fetch][1:0]==3)state[fetch]<=ROW_NEXT;else begin b=row_cache[(node[fetch][1:0]+1)*64+:64];last[fetch]<=b[31:0];if(b[63:32]!=0||b<a)local_error<=1;state[fetch]<=a==b?FREE:EDGE;end
     end else begin mem_valid<=1;mem_line<=row_base+(node[fetch]>>2);mem_id<={2'b00,fetch[1:0]};state[fetch]<=ROW_WAIT;row_beats<=row_beats+1;end
```
> The block can be copied into `frontend.sv` near line 43; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element b_reg was removed.

File: [frontend.sv:44](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/frontend.sv:44)

Reviewed parameter-dependent dead closed-scan state or procedural temporary/unused payload register. Do not add KEEP/DONT_TOUCH. Recheck after resolving root RAM errors; removal does not itself prove missing functionality.

|CSV S.No|Message|
|---|---|
|74|Unused sequential element b_reg was removed.|

Problematic context:
```diff
-       a=row_cache[node[fetch][1:0]*64+:64];pos[fetch]<=a[31:0];if(a[63:32]!=0)local_error<=1;
-       if(node[fetch][1:0]==3)state[fetch]<=ROW_NEXT;else begin b=row_cache[(node[fetch][1:0]+1)*64+:64];last[fetch]<=b[31:0];if(b[63:32]!=0||b<a)local_error<=1;state[fetch]<=a==b?FREE:EDGE;end
-      end else begin mem_valid<=1;mem_line<=row_base+(node[fetch]>>2);mem_id<={2'b00,fetch[1:0]};state[fetch]<=ROW_WAIT;row_beats<=row_beats+1;end
-     end
```
Recommended implementation / retained advisory context:
```diff
+       a=row_cache[node[fetch][1:0]*64+:64];pos[fetch]<=a[31:0];if(a[63:32]!=0)local_error<=1;
+       if(node[fetch][1:0]==3)state[fetch]<=ROW_NEXT;else begin b=row_cache[(node[fetch][1:0]+1)*64+:64];last[fetch]<=b[31:0];if(b[63:32]!=0||b<a)local_error<=1;state[fetch]<=a==b?FREE:EDGE;end
+      end else begin mem_valid<=1;mem_line<=row_base+(node[fetch]>>2);mem_id<={2'b00,fetch[1:0]};state[fetch]<=ROW_WAIT;row_beats<=row_beats+1;end
+     end
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
      a=row_cache[node[fetch][1:0]*64+:64];pos[fetch]<=a[31:0];if(a[63:32]!=0)local_error<=1;
      if(node[fetch][1:0]==3)state[fetch]<=ROW_NEXT;else begin b=row_cache[(node[fetch][1:0]+1)*64+:64];last[fetch]<=b[31:0];if(b[63:32]!=0||b<a)local_error<=1;state[fetch]<=a==b?FREE:EDGE;end
     end else begin mem_valid<=1;mem_line<=row_base+(node[fetch]>>2);mem_id<={2'b00,fetch[1:0]};state[fetch]<=ROW_WAIT;row_beats<=row_beats+1;end
    end
```
> The block can be copied into `frontend.sv` near line 44; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element s_reg was removed.

File: [frontend.sv:49](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/frontend.sv:49)

Reviewed parameter-dependent dead closed-scan state or procedural temporary/unused payload register. Do not add KEEP/DONT_TOUCH. Recheck after resolving root RAM errors; removal does not itself prove missing functionality.

|CSV S.No|Message|
|---|---|
|75|Unused sequential element s_reg was removed.|

Problematic context:
```diff
-    if(rsp_valid)begin
-     s=rsp_id[1:0];
-     if(rsp_id[3:2]==2)begin
-      beat[s]<=rsp_data;state[s]<=EMIT;
```
Recommended implementation / retained advisory context:
```diff
+    if(rsp_valid)begin
+     s=rsp_id[1:0];
+     if(rsp_id[3:2]==2)begin
+      beat[s]<=rsp_data;state[s]<=EMIT;
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
   if(rsp_valid)begin
    s=rsp_id[1:0];
    if(rsp_id[3:2]==2)begin
     beat[s]<=rsp_data;state[s]<=EMIT;
```
> The block can be copied into `frontend.sv` near line 49; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-4767: Trying to implement RAM 'last_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.

File: [frontend.sv:10](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/frontend.sv:10)

Reviewed: small multi-context register table with simultaneous updates/reads; register implementation is permitted and must be charged in actual utilization. No block-RAM claim is made for this table.

|CSV S.No|Message|
|---|---|
|76|Trying to implement RAM 'last_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|

Problematic context:
```diff
-  reg [2:0] state[0:3];localparam FREE=0,ROW=1,ROW_WAIT=2,ROW_NEXT=3,EDGE=4,EDGE_WAIT=5,EMIT=6,NEXT_WAIT=7;
-  reg [31:0] node[0:3],pos[0:3],last[0:3];reg [63:0] parent[0:3];reg [255:0] beat[0:3];
-  reg [63:0] costs[0:15];reg [1:0] rr;
-  // One-line row metadata reuse; all fetches and cache misses counted.
```
Recommended implementation / retained advisory context:
```diff
+  reg [2:0] state[0:3];localparam FREE=0,ROW=1,ROW_WAIT=2,ROW_NEXT=3,EDGE=4,EDGE_WAIT=5,EMIT=6,NEXT_WAIT=7;
+  reg [31:0] node[0:3],pos[0:3],last[0:3];reg [63:0] parent[0:3];reg [255:0] beat[0:3];
+  reg [63:0] costs[0:15];reg [1:0] rr;
+  // One-line row metadata reuse; all fetches and cache misses counted.
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
 reg [2:0] state[0:3];localparam FREE=0,ROW=1,ROW_WAIT=2,ROW_NEXT=3,EDGE=4,EDGE_WAIT=5,EMIT=6,NEXT_WAIT=7;
 reg [31:0] node[0:3],pos[0:3],last[0:3];reg [63:0] parent[0:3];reg [255:0] beat[0:3];
 reg [63:0] costs[0:15];reg [1:0] rr;
 // One-line row metadata reuse; all fetches and cache misses counted.
```
> The block can be copied into `frontend.sv` near line 10; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-4767: Trying to implement RAM 'pos_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.

File: [frontend.sv:10](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/frontend.sv:10)

Reviewed: small multi-context register table with simultaneous updates/reads; register implementation is permitted and must be charged in actual utilization. No block-RAM claim is made for this table.

|CSV S.No|Message|
|---|---|
|77|Trying to implement RAM 'pos_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|

Problematic context:
```diff
-  reg [2:0] state[0:3];localparam FREE=0,ROW=1,ROW_WAIT=2,ROW_NEXT=3,EDGE=4,EDGE_WAIT=5,EMIT=6,NEXT_WAIT=7;
-  reg [31:0] node[0:3],pos[0:3],last[0:3];reg [63:0] parent[0:3];reg [255:0] beat[0:3];
-  reg [63:0] costs[0:15];reg [1:0] rr;
-  // One-line row metadata reuse; all fetches and cache misses counted.
```
Recommended implementation / retained advisory context:
```diff
+  reg [2:0] state[0:3];localparam FREE=0,ROW=1,ROW_WAIT=2,ROW_NEXT=3,EDGE=4,EDGE_WAIT=5,EMIT=6,NEXT_WAIT=7;
+  reg [31:0] node[0:3],pos[0:3],last[0:3];reg [63:0] parent[0:3];reg [255:0] beat[0:3];
+  reg [63:0] costs[0:15];reg [1:0] rr;
+  // One-line row metadata reuse; all fetches and cache misses counted.
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
 reg [2:0] state[0:3];localparam FREE=0,ROW=1,ROW_WAIT=2,ROW_NEXT=3,EDGE=4,EDGE_WAIT=5,EMIT=6,NEXT_WAIT=7;
 reg [31:0] node[0:3],pos[0:3],last[0:3];reg [63:0] parent[0:3];reg [255:0] beat[0:3];
 reg [63:0] costs[0:15];reg [1:0] rr;
 // One-line row metadata reuse; all fetches and cache misses counted.
```
> The block can be copied into `frontend.sv` near line 10; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element evict_line_reg was removed.

File: [owner_pipeline.sv:102](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/owner_pipeline.sv:102)

Reviewed parameter-dependent dead closed-scan state or procedural temporary/unused payload register. Do not add KEEP/DONT_TOUCH. Recheck after resolving root RAM errors; removal does not itself prove missing functionality.

|CSV S.No|Message|
|---|---|
|78|Unused sequential element evict_line_reg was removed.|

Problematic context:
```diff
-     if(miss_dispatch)begin
-      sv<=1;skind<=1;sslot<=victim;sdirty<=dirty[victim];evict_line<=tags[victim];smiss<=fm;
-      if(dirty[victim])begin swrite<=fw;wv[fw]<=1;ws[fw]<=0;wg[fw]<=0;wl[fw]<=tags[victim];end
-      mv[fm]<=1;ms[fm]<=0;mg[fm]<=0;ml[fm]<=qline;slot_for_miss[fm]<=victim;mcount[fm]<=1;mc[fm]<={4{INF}};mc[fm][qd[65:64]*64+:64]<=qd[63:0];
```
Recommended implementation / retained advisory context:
```diff
+     if(miss_dispatch)begin
+      sv<=1;skind<=1;sslot<=victim;sdirty<=dirty[victim];evict_line<=tags[victim];smiss<=fm;
+      if(dirty[victim])begin swrite<=fw;wv[fw]<=1;ws[fw]<=0;wg[fw]<=0;wl[fw]<=tags[victim];end
+      mv[fm]<=1;ms[fm]<=0;mg[fm]<=0;ml[fm]<=qline;slot_for_miss[fm]<=victim;mcount[fm]<=1;mc[fm]<={4{INF}};mc[fm][qd[65:64]*64+:64]<=qd[63:0];
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
    if(miss_dispatch)begin
     sv<=1;skind<=1;sslot<=victim;sdirty<=dirty[victim];evict_line<=tags[victim];smiss<=fm;
     if(dirty[victim])begin swrite<=fw;wv[fw]<=1;ws[fw]<=0;wg[fw]<=0;wl[fw]<=tags[victim];end
     mv[fm]<=1;ms[fm]<=0;mg[fm]<=0;ml[fm]<=qline;slot_for_miss[fm]<=victim;mcount[fm]<=1;mc[fm]<={4{INF}};mc[fm][qd[65:64]*64+:64]<=qd[63:0];
```
> The block can be copied into `owner_pipeline.sv` near line 102; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-4767: Trying to implement RAM 'mc_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.

File: [owner_pipeline.sv:22](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/owner_pipeline.sv:22)

Reviewed: small multi-context register table with simultaneous updates/reads; register implementation is permitted and must be charged in actual utilization. No block-RAM claim is made for this table.

|CSV S.No|Message|
|---|---|
|79|Trying to implement RAM 'mc_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|

Problematic context:
```diff
-  reg [31:0] tags[0:127];reg [127:0] valid,dirty,busy;reg [1:0] replacement[0:31];
-  reg [31:0] ml[0:31],mcount[0:31];reg [6:0] slot_for_miss[0:31];reg [255:0] mc[0:31];reg [31:0] mv,ms,mg;
-  reg [31:0] wl[0:15];(* ram_style="block" *) reg [255:0] wb[0:15];reg [15:0] wv,ws,wg;reg [3:0] swrite;
-  reg sv,skind,sdirty;reg [6:0] sslot;reg [31:0] snode,sline,evict_line;reg [63:0] spair;reg [4:0] smiss;
```
Recommended implementation / retained advisory context:
```diff
+  reg [31:0] tags[0:127];reg [127:0] valid,dirty,busy;reg [1:0] replacement[0:31];
+  reg [31:0] ml[0:31],mcount[0:31];reg [6:0] slot_for_miss[0:31];reg [255:0] mc[0:31];reg [31:0] mv,ms,mg;
+  reg [31:0] wl[0:15];(* ram_style="block" *) reg [255:0] wb[0:15];reg [15:0] wv,ws,wg;reg [3:0] swrite;
+  reg sv,skind,sdirty;reg [6:0] sslot;reg [31:0] snode,sline,evict_line;reg [63:0] spair;reg [4:0] smiss;
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
 reg [31:0] tags[0:127];reg [127:0] valid,dirty,busy;reg [1:0] replacement[0:31];
 reg [31:0] ml[0:31],mcount[0:31];reg [6:0] slot_for_miss[0:31];reg [255:0] mc[0:31];reg [31:0] mv,ms,mg;
 reg [31:0] wl[0:15];(* ram_style="block" *) reg [255:0] wb[0:15];reg [15:0] wv,ws,wg;reg [3:0] swrite;
 reg sv,skind,sdirty;reg [6:0] sslot;reg [31:0] snode,sline,evict_line;reg [63:0] spair;reg [4:0] smiss;
```
> The block can be copied into `owner_pipeline.sv` near line 22; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-4767: Trying to implement RAM 'mcount_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.

File: [owner_pipeline.sv:22](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/owner_pipeline.sv:22)

Reviewed: small multi-context register table with simultaneous updates/reads; register implementation is permitted and must be charged in actual utilization. No block-RAM claim is made for this table.

|CSV S.No|Message|
|---|---|
|80|Trying to implement RAM 'mcount_reg' in registers. Block RAM or DRAM implementation is not possible; see log for reasons.|

Problematic context:
```diff
-  reg [31:0] tags[0:127];reg [127:0] valid,dirty,busy;reg [1:0] replacement[0:31];
-  reg [31:0] ml[0:31],mcount[0:31];reg [6:0] slot_for_miss[0:31];reg [255:0] mc[0:31];reg [31:0] mv,ms,mg;
-  reg [31:0] wl[0:15];(* ram_style="block" *) reg [255:0] wb[0:15];reg [15:0] wv,ws,wg;reg [3:0] swrite;
-  reg sv,skind,sdirty;reg [6:0] sslot;reg [31:0] snode,sline,evict_line;reg [63:0] spair;reg [4:0] smiss;
```
Recommended implementation / retained advisory context:
```diff
+  reg [31:0] tags[0:127];reg [127:0] valid,dirty,busy;reg [1:0] replacement[0:31];
+  reg [31:0] ml[0:31],mcount[0:31];reg [6:0] slot_for_miss[0:31];reg [255:0] mc[0:31];reg [31:0] mv,ms,mg;
+  reg [31:0] wl[0:15];(* ram_style="block" *) reg [255:0] wb[0:15];reg [15:0] wv,ws,wg;reg [3:0] swrite;
+  reg sv,skind,sdirty;reg [6:0] sslot;reg [31:0] snode,sline,evict_line;reg [63:0] spair;reg [4:0] smiss;
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
 reg [31:0] tags[0:127];reg [127:0] valid,dirty,busy;reg [1:0] replacement[0:31];
 reg [31:0] ml[0:31],mcount[0:31];reg [6:0] slot_for_miss[0:31];reg [255:0] mc[0:31];reg [31:0] mv,ms,mg;
 reg [31:0] wl[0:15];(* ram_style="block" *) reg [255:0] wb[0:15];reg [15:0] wv,ws,wg;reg [3:0] swrite;
 reg sv,skind,sdirty;reg [6:0] sslot;reg [31:0] snode,sline,evict_line;reg [63:0] spair;reg [4:0] smiss;
```
> The block can be copied into `owner_pipeline.sv` near line 22; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element issued_count_reg was removed.

File: [shared_fabric.sv:42](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/shared_fabric.sv:42)

Reviewed parameter-dependent dead closed-scan state or procedural temporary/unused payload register. Do not add KEEP/DONT_TOUCH. Recheck after resolving root RAM errors; removal does not itself prove missing functionality.

|CSV S.No|Message|
|---|---|
|144|Unused sequential element issued_count_reg was removed.|

Problematic context:
```diff
-   end else begin
-    issued_count=0;return_count=0;
-    for(integer p=0;p<P;p=p+1)begin
-     if(!mv[p]||mr[p])begin mv[p]<=0;if(tag[p]>=0&&selected[p]>=0)begin
```
Recommended implementation / retained advisory context:
```diff
+   end else begin
+    issued_count=0;return_count=0;
+    for(integer p=0;p<P;p=p+1)begin
+     if(!mv[p]||mr[p])begin mv[p]<=0;if(tag[p]>=0&&selected[p]>=0)begin
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
  end else begin
   issued_count=0;return_count=0;
   for(integer p=0;p<P;p=p+1)begin
    if(!mv[p]||mr[p])begin mv[p]<=0;if(tag[p]>=0&&selected[p]>=0)begin
```
> The block can be copied into `shared_fabric.sv` near line 42; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element return_count_reg was removed.

File: [shared_fabric.sv:42](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/shared_fabric.sv:42)

Reviewed parameter-dependent dead closed-scan state or procedural temporary/unused payload register. Do not add KEEP/DONT_TOUCH. Recheck after resolving root RAM errors; removal does not itself prove missing functionality.

|CSV S.No|Message|
|---|---|
|145|Unused sequential element return_count_reg was removed.|

Problematic context:
```diff
-   end else begin
-    issued_count=0;return_count=0;
-    for(integer p=0;p<P;p=p+1)begin
-     if(!mv[p]||mr[p])begin mv[p]<=0;if(tag[p]>=0&&selected[p]>=0)begin
```
Recommended implementation / retained advisory context:
```diff
+   end else begin
+    issued_count=0;return_count=0;
+    for(integer p=0;p<P;p=p+1)begin
+     if(!mv[p]||mr[p])begin mv[p]<=0;if(tag[p]>=0&&selected[p]>=0)begin
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
  end else begin
   issued_count=0;return_count=0;
   for(integer p=0;p<P;p=p+1)begin
    if(!mv[p]||mr[p])begin mv[p]<=0;if(tag[p]>=0&&selected[p]>=0)begin
```
> The block can be copied into `shared_fabric.sv` near line 42; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element branch_op_reg[*] was removed.

File: [control_tree.sv:12](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/control_tree.sv:12)

Actionable physical-control concern: unconditional equal branch copies can merge. Gate each branch by its own group completion (plus neutral/reset), retaining explicit distributed command acceptance. Recheck actual fanout after successful synthesis.

|CSV S.No|Message|
|---|---|
|146|Unused sequential element branch_op_reg[1] was removed.|

Problematic context:
```diff
-   if(rst)begin root_op<=7;root_epoch<=0;leaf_op<={8{3'd7}};leaf_epoch<=0;ack<=0;group_done<=0;
-    for(integer i=0;i<2;i=i+1)begin branch_op[i]<=7;branch_epoch[i]<=0;group_epoch[i]<=0;end
-    for(integer i=0;i<8;i=i+1)ack_epoch[i]<=0;
-   end else begin
```
Recommended implementation / retained advisory context:
```diff
+ if ((&leaf_done[i*4+:4]) || branch_op[i]==0 || branch_op[i]==7) begin
+   branch_op[i] <= root_op; branch_epoch[i] <= root_epoch;
+ end
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
if ((&leaf_done[i*4+:4]) || branch_op[i]==0 || branch_op[i]==7) begin
  branch_op[i] <= root_op; branch_epoch[i] <= root_epoch;
end
```
> The block can be copied into `control_tree.sv` near line 12; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element branch_epoch_reg[*] was removed.

File: [control_tree.sv:12](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/control_tree.sv:12)

Actionable physical-control concern: unconditional equal branch copies can merge. Gate each branch by its own group completion (plus neutral/reset), retaining explicit distributed command acceptance. Recheck actual fanout after successful synthesis.

|CSV S.No|Message|
|---|---|
|147|Unused sequential element branch_epoch_reg[1] was removed.|

Problematic context:
```diff
-   if(rst)begin root_op<=7;root_epoch<=0;leaf_op<={8{3'd7}};leaf_epoch<=0;ack<=0;group_done<=0;
-    for(integer i=0;i<2;i=i+1)begin branch_op[i]<=7;branch_epoch[i]<=0;group_epoch[i]<=0;end
-    for(integer i=0;i<8;i=i+1)ack_epoch[i]<=0;
-   end else begin
```
Recommended implementation / retained advisory context:
```diff
+ if ((&leaf_done[i*4+:4]) || branch_op[i]==0 || branch_op[i]==7) begin
+   branch_op[i] <= root_op; branch_epoch[i] <= root_epoch;
+ end
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
if ((&leaf_done[i*4+:4]) || branch_op[i]==0 || branch_op[i]==7) begin
  branch_op[i] <= root_op; branch_epoch[i] <= root_epoch;
end
```
> The block can be copied into `control_tree.sv` near line 12; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element requests_reg was removed.

File: [router.sv:23](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/router.sv:23)

Reviewed parameter-dependent dead closed-scan state or procedural temporary/unused payload register. Do not add KEEP/DONT_TOUCH. Recheck after resolving root RAM errors; removal does not itself prove missing functionality.

|CSV S.No|Message|
|---|---|
|148|Unused sequential element requests_reg was removed.|

Problematic context:
```diff
-  always @(posedge clk)if(rst)begin conflicts<=0;for(o=0;o<8;o=o+1)rr[o]<=0;end else begin
-   requests=0;for(k=0;k<8;k=k+1)if(iv[k]&&!ir[k])requests=requests+1;
-   conflicts<=conflicts+requests;
-   for(o=0;o<8;o=o+1)if(put[o]&&put_ready[o])rr[o]<=rr[o]+1;
```
Recommended implementation / retained advisory context:
```diff
+  always @(posedge clk)if(rst)begin conflicts<=0;for(o=0;o<8;o=o+1)rr[o]<=0;end else begin
+   requests=0;for(k=0;k<8;k=k+1)if(iv[k]&&!ir[k])requests=requests+1;
+   conflicts<=conflicts+requests;
+   for(o=0;o<8;o=o+1)if(put[o]&&put_ready[o])rr[o]<=rr[o]+1;
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
 always @(posedge clk)if(rst)begin conflicts<=0;for(o=0;o<8;o=o+1)rr[o]<=0;end else begin
  requests=0;for(k=0;k<8;k=k+1)if(iv[k]&&!ir[k])requests=requests+1;
  conflicts<=conflicts+requests;
  for(o=0;o<8;o=o+1)if(put[o]&&put_ready[o])rr[o]<=rr[o]+1;
```
> The block can be copied into `router.sv` near line 23; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element banks[*].leaf_cost_we_reg was removed.

File: [sparse_tile.sv:51](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/sparse_tile.sv:51)

Actionable physical-distribution concern: equivalent cost copies can merge. Gate each leaf preload with its local reset/neutral command and acknowledge the final cost index before descriptor dispatch. The failed elaboration cannot establish complete connectivity.

|CSV S.No|Message|
|---|---|
|149|Unused sequential element banks[1].leaf_cost_we_reg was removed.|
|152|Unused sequential element banks[2].leaf_cost_we_reg was removed.|
|155|Unused sequential element banks[3].leaf_cost_we_reg was removed.|
|158|Unused sequential element banks[4].leaf_cost_we_reg was removed.|
|161|Unused sequential element banks[5].leaf_cost_we_reg was removed.|
|164|Unused sequential element banks[6].leaf_cost_we_reg was removed.|
|167|Unused sequential element banks[7].leaf_cost_we_reg was removed.|

Problematic context:
```diff
-   reg leaf_cost_we;reg [3:0] leaf_cost_index;reg [63:0] leaf_cost_data;
-   always @(posedge clk)begin leaf_cost_we<=cost_we;leaf_cost_index<=cost_index;leaf_cost_data<=cost_data;end
-   wire fav,far,mav,mar,fork_idle;wire [31:0] fan,man;wire [63:0] fap,mapair;wire [31:0] pop_count;
-   if(POP_REDUCE)begin:online
```
Recommended implementation / retained advisory context:
```diff
+ leaf_cost_we <= cost_we && (leaf_command==7 || leaf_command==0);
+ if (cost_we && (leaf_command==7 || leaf_command==0)) begin
+   leaf_cost_index <= cost_index; leaf_cost_data <= cost_data;
+ end
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
leaf_cost_we <= cost_we && (leaf_command==7 || leaf_command==0);
if (cost_we && (leaf_command==7 || leaf_command==0)) begin
  leaf_cost_index <= cost_index; leaf_cost_data <= cost_data;
end
```
> The block can be copied into `sparse_tile.sv` near line 51; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element banks[*].leaf_cost_index_reg was removed.

File: [sparse_tile.sv:51](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/sparse_tile.sv:51)

Actionable physical-distribution concern: equivalent cost copies can merge. Gate each leaf preload with its local reset/neutral command and acknowledge the final cost index before descriptor dispatch. The failed elaboration cannot establish complete connectivity.

|CSV S.No|Message|
|---|---|
|150|Unused sequential element banks[1].leaf_cost_index_reg was removed.|
|153|Unused sequential element banks[2].leaf_cost_index_reg was removed.|
|156|Unused sequential element banks[3].leaf_cost_index_reg was removed.|
|159|Unused sequential element banks[4].leaf_cost_index_reg was removed.|
|162|Unused sequential element banks[5].leaf_cost_index_reg was removed.|
|165|Unused sequential element banks[6].leaf_cost_index_reg was removed.|
|168|Unused sequential element banks[7].leaf_cost_index_reg was removed.|

Problematic context:
```diff
-   reg leaf_cost_we;reg [3:0] leaf_cost_index;reg [63:0] leaf_cost_data;
-   always @(posedge clk)begin leaf_cost_we<=cost_we;leaf_cost_index<=cost_index;leaf_cost_data<=cost_data;end
-   wire fav,far,mav,mar,fork_idle;wire [31:0] fan,man;wire [63:0] fap,mapair;wire [31:0] pop_count;
-   if(POP_REDUCE)begin:online
```
Recommended implementation / retained advisory context:
```diff
+ leaf_cost_we <= cost_we && (leaf_command==7 || leaf_command==0);
+ if (cost_we && (leaf_command==7 || leaf_command==0)) begin
+   leaf_cost_index <= cost_index; leaf_cost_data <= cost_data;
+ end
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
leaf_cost_we <= cost_we && (leaf_command==7 || leaf_command==0);
if (cost_we && (leaf_command==7 || leaf_command==0)) begin
  leaf_cost_index <= cost_index; leaf_cost_data <= cost_data;
end
```
> The block can be copied into `sparse_tile.sv` near line 51; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


### Synth 8-6014: Unused sequential element banks[*].leaf_cost_data_reg was removed.

File: [sparse_tile.sv:51](/inspire/hdd/global_user/guoruiyuan-253208540291/FPGA_routing_acceleration/3D_FPGA_Interconnects_SPARSE_STREAM_R2/results/fpga_sparse_stream_r2_20261112/rtl/pipe_full_c_build/source/sparse_tile.sv:51)

Actionable physical-distribution concern: equivalent cost copies can merge. Gate each leaf preload with its local reset/neutral command and acknowledge the final cost index before descriptor dispatch. The failed elaboration cannot establish complete connectivity.

|CSV S.No|Message|
|---|---|
|151|Unused sequential element banks[1].leaf_cost_data_reg was removed.|
|154|Unused sequential element banks[2].leaf_cost_data_reg was removed.|
|157|Unused sequential element banks[3].leaf_cost_data_reg was removed.|
|160|Unused sequential element banks[4].leaf_cost_data_reg was removed.|
|163|Unused sequential element banks[5].leaf_cost_data_reg was removed.|
|166|Unused sequential element banks[6].leaf_cost_data_reg was removed.|
|169|Unused sequential element banks[7].leaf_cost_data_reg was removed.|

Problematic context:
```diff
-   reg leaf_cost_we;reg [3:0] leaf_cost_index;reg [63:0] leaf_cost_data;
-   always @(posedge clk)begin leaf_cost_we<=cost_we;leaf_cost_index<=cost_index;leaf_cost_data<=cost_data;end
-   wire fav,far,mav,mar,fork_idle;wire [31:0] fan,man;wire [63:0] fap,mapair;wire [31:0] pop_count;
-   if(POP_REDUCE)begin:online
```
Recommended implementation / retained advisory context:
```diff
+ leaf_cost_we <= cost_we && (leaf_command==7 || leaf_command==0);
+ if (cost_we && (leaf_command==7 || leaf_command==0)) begin
+   leaf_cost_index <= cost_index; leaf_cost_data <= cost_data;
+ end
```
Corrected code (or unchanged reviewed advisory context):
```systemverilog
leaf_cost_we <= cost_we && (leaf_command==7 || leaf_command==0);
if (cost_we && (leaf_command==7 || leaf_command==0)) begin
  leaf_cost_index <= cost_index; leaf_cost_data <= cost_data;
end
```
> The block can be copied into `sparse_tile.sv` near line 51; actionable RAM-port fragments replace the corresponding scattered access sites as one complete repair. Advisory blocks are unchanged context, not suppression directives.


## Verification

107 / 107 non-INFO occurrences accounted for in 26 distinct diagnostic groups. All listed source files were read. Actionable snippets are implemented together in the next source version and checked by RTL regressions plus synthesis. No successful OOC or resource result is inferred from this failed run.
